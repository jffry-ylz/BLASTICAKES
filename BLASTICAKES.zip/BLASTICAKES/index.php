<?php
// Start session
session_start();

// Check if user is logged in
$logged_in = isset($_SESSION['user_id']);
$username = $logged_in ? $_SESSION['username'] : '';
$is_admin = $logged_in && isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;

// If user is admin, redirect to admin.php
if ($is_admin) {
    header("Location: admin.php");
    exit();
}

// Include database connection
require_once 'includes/db.php';

// Fetch products from database
$products = [];
$featured_products = [];

// Check if products table exists
$table_exists = mysqli_query($conn, "SHOW TABLES LIKE 'products'");
if (mysqli_num_rows($table_exists) > 0) {
    // Get all products
    $sql = "SELECT * FROM products WHERE stock > 0 ORDER BY id DESC";
    $result = mysqli_query($conn, $sql);
    
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            $products[] = $row;
        }
        
        // Get featured products (latest 4 products)
        $featured_products = array_slice($products, 0, 4);
    }
}

// Get product categories
$categories = [];
if (!empty($products)) {
    foreach ($products as $product) {
        if (!in_array($product['category'], $categories)) {
            $categories[] = $product['category'];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Home - BLASTICAKES & CRAFTS</title>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
        }
        
        header {
            background-color: #ff6b6b;
            color: white;
            padding: 10px 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
        }
        
        header h1 {
            margin: 0;
            font-size: 28px;
        }
        
        nav ul {
            list-style: none;
            display: flex;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            margin-left: 20px;
        }
        
        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        
        nav ul li a:hover {
            background-color: rgba(255,255,255,0.2);
        }
        
        .welcome {
            background-color: white;
            border-radius: 5px;
            padding: 30px;
            margin-top: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .welcome h2 {
            color: #ff6b6b;
            margin-top: 0;
        }
        
        .welcome a {
            color: #ff6b6b;
            text-decoration: none;
            font-weight: bold;
        }
        
        .welcome a:hover {
            text-decoration: underline;
        }
        
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 20px 0;
            margin-top: 50px;
        }
        
        /* Product display styles */
        .hero-banner {
            background-color: #ffeded;
            padding: 60px 0;
            text-align: center;
            margin-bottom: 40px;
            border-radius: 5px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        .hero-banner h2 {
            color: #ff6b6b;
            font-size: 2.5em;
            margin-bottom: 20px;
        }
        .hero-banner p {
            color: #666;
            font-size: 1.2em;
            max-width: 800px;
            margin: 0 auto 30px;
        }
        .btn {
            display: inline-block;
            background-color: #ff6b6b;
            color: white;
            padding: 12px 25px;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
            transition: background-color 0.3s;
        }
        .btn:hover {
            background-color: #ff5252;
        }
        .section-title {
            text-align: center;
            margin: 40px 0 30px;
            color: #333;
            position: relative;
        }
        .section-title:after {
            content: '';
            display: block;
            width: 80px;
            height: 3px;
            background-color: #ff6b6b;
            margin: 15px auto 0;
        }
        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 30px;
            margin-bottom: 40px;
        }
        .product-card {
            background-color: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        .product-image {
            height: 200px;
            overflow: hidden;
        }
        
        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s;
        }
        .product-card:hover .product-image img {
            transform: scale(1.05);
        }
        .product-details {
            padding: 20px;
        }
        .product-title {
            font-size: 1.2em;
            margin: 0 0 10px;
            color: #333;
        }
        .product-category {
            display: inline-block;
            background-color: #f0f0f0;
            color: #666;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.8em;
            margin-bottom: 10px;
            text-transform: capitalize;
        }
        .product-price {
            font-size: 1.3em;
            color: #ff6b6b;
            font-weight: bold;
            margin: 10px 0;
        }
        .product-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 15px;
        }
        .view-btn {
            padding: 8px 15px;
            background-color: #f0f0f0;
            color: #333;
            text-decoration: none;
            border-radius: 4px;
            font-size: 0.9em;
            transition: background-color 0.3s;
        }
        .view-btn:hover {
            background-color: #e0e0e0;
        }
        .add-to-cart-btn {
            padding: 8px 15px;
            background-color: #ff6b6b;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-size: 0.9em;
            transition: background-color 0.3s;
        }
        .add-to-cart-btn:hover {
            background-color: #ff5252;
        }
        .category-section {
            margin: 60px 0;
        }
        .view-all {
            text-align: center;
            margin-top: 20px;
        }
        .view-all a {
            color: #ff6b6b;
            text-decoration: none;
            font-weight: bold;
            transition: color 0.3s;
        }
        .view-all a:hover {
            color: #ff5252;
        }
        /* Empty state */
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin: 30px 0;
        }
        .empty-state i {
            font-size: 50px;
            color: #ddd;
            margin-bottom: 20px;
        }
        .empty-state h3 {
            color: #666;
            margin-bottom: 10px;
        }
        .empty-state p {
            color: #999;
            margin-bottom: 20px;
        }
        
        /* User dropdown menu */
        .user-dropdown {
            position: relative;
            display: inline-block;
        }
        
        .user-dropdown-btn {
            display: flex;
            align-items: center;
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .user-dropdown-btn:hover {
            background-color: rgba(255,255,255,0.2);
        }
        
        .user-dropdown-btn img {
            width: 25px;
            height: 25px;
            border-radius: 50%;
            margin-right: 8px;
            object-fit: cover;
        }
        
        .user-dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 180px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .user-dropdown-content a {
            color: #333;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }
        
        .user-dropdown-content a:hover {
            background-color: #f1f1f1;
        }
        
        .user-dropdown:hover .user-dropdown-content {
            display: block;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>BLASTICAKES & CRAFTS</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="products.php">Products</a></li>
                    <?php if ($logged_in): ?>
                        <li><a href="my_orders.php">My Orders</a></li>
                        <li><a href="cart.php">Cart</a></li>
                        <li class="user-dropdown">
                            <div class="user-dropdown-btn">
                                <?php 
                                // Get user profile picture
                                $user_id = $_SESSION['user_id'];
                                $profile_query = "SELECT profile_picture FROM users WHERE id = ?";
                                $stmt = mysqli_prepare($conn, $profile_query);
                                mysqli_stmt_bind_param($stmt, "i", $user_id);
                                mysqli_stmt_execute($stmt);
                                $profile_result = mysqli_stmt_get_result($stmt);
                                $profile_pic = 'default_profile.png'; // Default image
                                
                                if ($profile_row = mysqli_fetch_assoc($profile_result)) {
                                    if (!empty($profile_row['profile_picture'])) {
                                        $profile_pic = $profile_row['profile_picture'];
                                    }
                                }
                                ?>
                                <img src="profile_images/<?php echo $profile_pic; ?>" alt="Profile">
                            </div>
                            <div class="user-dropdown-content">
                                <a href="account.php"><i class="fas fa-user"></i> My Account</a>
                                <a href="my_orders.php"><i class="fas fa-shopping-bag"></i> My Orders</a>
                                <a href="change_password.php"><i class="fas fa-key"></i> Change Password</a>
                                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                            </div>
                        </li>
                    <?php else: ?>
                        <li><a href="login.php">Login</a></li>
                        <li><a href="signup.php">Sign Up</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>
    
    <!-- Regular User Welcome and Product Display -->
    <div class="container">
        <!-- Hero Banner -->
        <div class="hero-banner">
            <h2>Welcome to BLASTICAKES & CRAFTS</h2>
            <p>Discover our delicious cakes and beautiful crafts for all your special occasions.</p>
            <a href="products.php" class="btn">Shop Now</a>
        </div>
        
        <!-- Featured Products Section -->
        <h2 class="section-title">Featured Products</h2>
        
        <?php if (empty($featured_products)): ?>
            <div class="empty-state">
                <i class="fas fa-birthday-cake"></i>
                <h3>No Products Available Yet</h3>
                <p>Check back soon for our delicious cakes and beautiful crafts!</p>
                <?php if ($logged_in): ?>
                    <a href="products.php" class="btn">Browse All Products</a>
                <?php else: ?>
                    <a href="login.php" class="btn">Login to Shop</a>
                    
                <?php endif; ?>
            </div>
        <?php else: ?>
            <div class="products-grid">
                <?php foreach ($featured_products as $product): ?>
                    <div class="product-card">
                        <div class="product-image">
                                                        <img src="images/<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                        </div>
                        <div class="product-details">
                            <span class="product-category"><?php echo htmlspecialchars(ucfirst($product['category'])); ?></span>
                            <h3 class="product-title"><?php echo htmlspecialchars($product['name']); ?></h3>
                            <p class="product-price">₱<?php echo number_format($product['price'], 2); ?></p>
                            <div class="product-actions">
                                <a href="product_details.php?id=<?php echo $product['id']; ?>" class="view-btn">View Details</a>
                                <?php if ($logged_in): ?>
                                    <a href="add_to_cart.php?id=<?php echo $product['id']; ?>" class="add-to-cart-btn">Add to Cart</a>
                                <?php else: ?>
                                    <a href="login.php" class="add-to-cart-btn">Login to Buy</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <div class="view-all">
                <a href="products.php">View All Products <i class="fas fa-arrow-right"></i></a>
            </div>
        <?php endif; ?>
        
        <!-- Category Sections -->
        <?php foreach ($categories as $category): ?>
            <div class="category-section">
                <h2 class="section-title"><?php echo ucfirst(htmlspecialchars($category)); ?> Collection</h2>
                <div class="products-grid">
                    <?php 
                    $category_products = array_filter($products, function($p) use ($category) {
                        return $p['category'] === $category;
                    });
                    
                    // Get first 4 products of this category
                    $category_products = array_slice($category_products, 0, 4);
                    
                    foreach ($category_products as $product): 
                    ?>
                        <div class="product-card">
                            <div class="product-image">
                                <img src="images/<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                            </div>
                            <div class="product-details">
                                <span class="product-category"><?php echo htmlspecialchars(ucfirst($product['category'])); ?></span>
                                <h3 class="product-title"><?php echo htmlspecialchars($product['name']); ?></h3>
                                <p class="product-price">₱<?php echo number_format($product['price'], 2); ?></p>
                                <div class="product-actions">
                                    <a href="product_details.php?id=<?php echo $product['id']; ?>" class="view-btn">View Details</a>
                                    
                                    <?php if ($logged_in): ?>
                                        <a href="add_to_cart.php?id=<?php echo $product['id']; ?>" class="add-to-cart-btn">Add to Cart</a>
                                    <?php else: ?>
                                        <a href="login.php" class="add-to-cart-btn">Login to Buy</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
                <div class="view-all">
                    <a href="products.php?category=<?php echo urlencode($category); ?>">View All <?php echo ucfirst(htmlspecialchars($category)); ?> <i class="fas fa-arrow-right"></i></a>
                </div>
            </div>
        <?php endforeach; ?>
        
        <!-- About Us Section -->
        <div class="welcome">
            <h2>About BLASTICAKES & CRAFTS</h2>
            <p>We specialize in creating delicious cakes and beautiful crafts for all your special occasions. From birthdays to weddings, our handcrafted products will make your celebration unforgettable.</p>
            
            <?php if (!$logged_in): ?>
                <p>Please <a href="login.php">login</a> or <a href="signup.php">sign up</a> to start shopping!</p>
            <?php endif; ?>
        </div>
    </div>
    
    <footer>
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> BLASTICAKES & CRAFTS. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
