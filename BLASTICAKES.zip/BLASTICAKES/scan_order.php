<?php
// Start session
session_start();

// Check if user is logged in and is admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header("Location: login.php");
    exit;
}

// Include database connection
require_once 'includes/db.php';

// Get user info
$username = $_SESSION['username'];

// Initialize variables
$order_data = null;
$order_details = null;
$order_items = [];
$customer_info = null;
$scan_result = '';

// Process scanned QR code data
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['qr_data'])) {
    $qr_data = trim($_POST['qr_data']);
    
    // Try to decode the JSON data from QR code
    $decoded_data = json_decode($qr_data, true);
    
    if ($decoded_data && isset($decoded_data['order_id'])) {
        $order_id = $decoded_data['order_id'];
        
        // Get order details
        $sql = "SELECT o.*, u.username, u.email as user_email 
                FROM orders o 
                JOIN users u ON o.user_id = u.id 
                WHERE o.id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $order_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        if (mysqli_num_rows($result) > 0) {
            $order_details = mysqli_fetch_assoc($result);
            
            // Get order items
            $sql = "SELECT oi.*, p.name, p.image 
                    FROM order_items oi 
                    JOIN products p ON oi.product_id = p.id 
                    WHERE oi.order_id = ?";
            $stmt = mysqli_prepare($conn, $sql);
            mysqli_stmt_bind_param($stmt, "i", $order_id);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);
            
            while ($row = mysqli_fetch_assoc($result)) {
                $order_items[] = $row;
            }
            
            $scan_result = 'success';
            $order_data = $decoded_data;
        } else {
            $scan_result = 'error';
        }
    } else {
        $scan_result = 'invalid';
    }
}

// Process order status update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $new_status = $_POST['status'];
    
    $sql = "UPDATE orders SET status = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "si", $new_status, $order_id);
    
    if (mysqli_stmt_execute($stmt)) {
        // Refresh order details
        $sql = "SELECT o.*, u.username, u.email as user_email 
                FROM orders o 
                JOIN users u ON o.user_id = u.id 
                WHERE o.id = ?";
        $stmt = mysqli_prepare($conn, $sql);
        mysqli_stmt_bind_param($stmt, "i", $order_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        if (mysqli_num_rows($result) > 0) {
            $order_details = mysqli_fetch_assoc($result);
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Scan Order QR - BLASTICAKES & CRAFTS</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        header {
            background-color: #ff6b6b;
            color: white;
            padding: 1rem;
        }
        .container {
            width: 90%;
            margin: 0 auto;
            overflow: hidden;
        }
        nav {
            float: right;
        }
        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
        }
        nav li {
            display: inline;
            margin-left: 15px;
        }
        nav a {
            color: white;
            text-decoration: none;
        }
        .scanner-container {
            background: white;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-top: 20px;
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }
        .scanner-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        .btn {
            display: inline-block;
            background-color: #ff6b6b;
            color: white;
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 4px;
            border: none;
            cursor: pointer;
        }
        .btn:hover {
            background-color: #ff5252;
        }
        .btn-secondary {
            background-color: #6c757d;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        textarea {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
            height: 100px;
        }
        .scanner-section {
            margin-bottom: 20px;
        }
        .scanner-section h3 {
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }
        .order-details {
            background: #f9f9f9;
            padding: 15px;
            border-radius: 4px;
            margin-top: 20px;
        }
        .order-info {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin-bottom: 20px;
        }
        .order-info-item {
            flex: 1;
            min-width: 200px;
        }
        .order-info-label {
            font-weight: bold;
            color: #666;
        }
        .order-items {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .order-items th, .order-items td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .order-items th {
            background-color: #f2f2f2;
        }
        .product-img {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 4px;
        }
        .status-pending {
            color: #f39c12;
        }
        .status-processing {
            color: #3498db;
        }
        .status-completed {
            color: #27ae60;
        }
        .status-cancelled {
            color: #e74c3c;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 4px;
        }
        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }
        .alert-danger {
            color: #721c24;
            background-color: #f8d7da;
            border-color: #f5c6cb;
        }
        .alert-warning {
            color: #856404;
            background-color: #fff3cd;
            border-color: #ffeeba;
        }
        .video-container {
            width: 100%;
            max-width: 500px;
            margin: 0 auto;
            overflow: hidden;
            border-radius: 4px;
            border: 1px solid #ddd;
        }
        #qr-video {
            width: 100%;
            height: auto;
        }
        .scanner-controls {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
        }
        select {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .customer-info {
            background: #e9f7fe;
            padding: 15px;
            border-radius: 4px;
            margin-top: 20px;
            border-left: 4px solid #3498db;
        }
        .customer-info h4 {
            margin-top: 0;
            color: #3498db;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>BLASTICAKES & CRAFTS</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="products.php">Products</a></li>
                    <li><a href="admin.php">Admin Panel</a></li>
                    <li><a href="logout.php">Logout (<?php echo $username; ?>)</a></li>
                </ul>
            </nav>
        </div>
    </header>
    
    <div class="container">
        <h2>Scan Order QR Code</h2>
        
        <div class="scanner-container">
            <div class="scanner-section">
                <h3>QR Code Scanner</h3>
                
                <div id="camera-scanner" class="scan-method">
                    <div class="video-container">
                        <video id="qr-video" playsinline></video>
                    </div>
                    <div class="scanner-controls">
                        <button id="start-button" class="btn">Start Scanner</button>
                        <button id="stop-button" class="btn btn-secondary" disabled>Stop Scanner</button>
                    </div>
                </div>
            </div>
            
            <?php if ($scan_result === 'success'): ?>
                <div class="alert alert-success">
                    <strong>Success!</strong> Order found and loaded successfully.
                </div>
                
                <div class="order-details">
                    <h3>Order #<?php echo $order_details['id']; ?></h3>
                    
                    <div class="order-info">
                        <div class="order-info-item">
                            <div class="order-info-label">Order Date:</div>
                            <div><?php echo date('F j, Y, g:i a', strtotime($order_details['order_date'])); ?></div>
                        </div>
                        
                        <div class="order-info-item">
                            <div class="order-info-label">Total Amount:</div>
                            <div>₱<?php echo number_format($order_details['total_amount'], 2); ?></div>
                        </div>
                        
                        <div class="order-info-item">
                            <div class="order-info-label">Payment Method:</div>
                            <div><?php echo $order_details['payment_method']; ?></div>
                        </div>
                        
                        <div class="order-info-item">
                            <div class="order-info-label">Status:</div>
                            <div class="status-<?php echo $order_details['status']; ?>">
                                <?php echo ucfirst($order_details['status']); ?>
                            </div>
                        </div>
                    </div>
                    
                    <div class="customer-info">
                        <h4>Customer Information</h4>
                        <div class="order-info">
                            <div class="order-info-item">
                                <div class="order-info-label">Username:</div>
                                <div><?php echo $order_details['username']; ?></div>
                            </div>
                            
                            <div class="order-info-item">
                                <div class="order-info-label">Email:</div>
                                <div><?php echo $order_details['user_email']; ?></div>
                            </div>
                            
                            <div class="order-info-item">
                                <div class="order-info-label">Phone:</div>
                                <div><?php echo $order_details['phone']; ?></div>
                            </div>
                            
                            <div class="order-info-item">
                                <div class="order-info-label">Address:</div>
                                <div><?php echo $order_details['address']; ?></div>
                            </div>
                        </div>
                    </div>
                    
                    <h4>Order Items</h4>
                    <table class="order-items">
                        <thead>
                            <tr>
                                <th>Image</th>
                                <th>Product</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($order_items as $item): ?>
                                <tr>
                                    <td><img src="images/<?php echo $item['image']; ?>" alt="<?php echo $item['name']; ?>" class="product-img"></td>
                                    <td><?php echo $item['name']; ?></td>
                                    <td>₱<?php echo number_format($item['price'], 2); ?></td>
                                    <td><?php echo $item['quantity']; ?></td>
                                    <td>₱<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4" style="text-align: right;"><strong>Total:</strong></td>
                                <td><strong>₱<?php echo number_format($order_details['total_amount'], 2); ?></strong></td>
                            </tr>
                        </tfoot>
                    </table>
                    
                    <div style="margin-top: 20px;">
                        <h4>Update Order Status</h4>
                        <form action="scan_order.php" method="post">
                                                        <input type="hidden" name="order_id" value="<?php echo $order_details['id']; ?>">
                            <div style="display: flex; gap: 10px; align-items: center;">
                                <select name="status" style="flex: 1;">
                                    <option value="pending" <?php echo $order_details['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="processing" <?php echo $order_details['status'] == 'processing' ? 'selected' : ''; ?>>Processing</option>
                                    <option value="completed" <?php echo $order_details['status'] == 'completed' ? 'selected' : ''; ?>>Completed</option>
                                    <option value="cancelled" <?php echo $order_details['status'] == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                </select>
                                <button type="submit" name="update_status" class="btn">Update Status</button>
                            </div>
                        </form>
                    </div>
                </div>
            <?php elseif ($scan_result === 'error'): ?>
                <div class="alert alert-danger">
                    <strong>Error!</strong> Order not found in the database.
                </div>
            <?php elseif ($scan_result === 'invalid'): ?>
                <div class="alert alert-warning">
                    <strong>Warning!</strong> Invalid QR code data. Please scan a valid order QR code.
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <!-- Include the QR code scanner library -->
    <script src="https://unpkg.com/@zxing/library@latest/umd/index.min.js"></script>
    <script>
        // QR Code Scanner functionality
        const cameraScanner = document.getElementById('camera-scanner');
        const video = document.getElementById('qr-video');
        const startButton = document.getElementById('start-button');
        const stopButton = document.getElementById('stop-button');
        
        let selectedDeviceId;
        let codeReader;
        
        function startScanner() {
            codeReader = new ZXing.BrowserQRCodeReader();
            
            codeReader.getVideoInputDevices()
                .then((videoInputDevices) => {
                    if (videoInputDevices.length > 0) {
                        selectedDeviceId = videoInputDevices[0].deviceId;
                        
                        // If there are multiple cameras, prefer the environment-facing (back) camera
                        videoInputDevices.forEach((device) => {
                            if (device.label.toLowerCase().includes('back')) {
                                selectedDeviceId = device.deviceId;
                            }
                        });
                        
                        startButton.disabled = true;
                        stopButton.disabled = false;
                        
                        codeReader.decodeFromVideoDevice(selectedDeviceId, 'qr-video', (result, err) => {
                            if (result) {
                                console.log('QR Code detected:', result.text);
                                
                                // Submit the QR code data to the server
                                const form = document.createElement('form');
                                form.method = 'POST';
                                form.action = 'scan_order.php';
                                
                                const input = document.createElement('input');
                                input.type = 'hidden';
                                input.name = 'qr_data';
                                input.value = result.text;
                                
                                form.appendChild(input);
                                document.body.appendChild(form);
                                form.submit();
                                
                                stopScanner();
                            }
                            
                            if (err && !(err instanceof ZXing.NotFoundException)) {
                                console.error('QR Code scanning error:', err);
                            }
                        });
                    } else {
                        alert('No video input devices found');
                    }
                })
                .catch((err) => {
                    console.error('Error accessing camera:', err);
                    alert('Error accessing camera: ' + err.message);
                });
        }
        
        function stopScanner() {
            if (codeReader) {
                codeReader.reset();
                startButton.disabled = false;
                stopButton.disabled = true;
            }
        }
        
        startButton.addEventListener('click', startScanner);
        stopButton.addEventListener('click', stopScanner);
        
        // Clean up when page is unloaded
        window.addEventListener('beforeunload', () => {
            if (codeReader) {
                codeReader.reset();
            }
        });
    </script>
</body>
</html>
