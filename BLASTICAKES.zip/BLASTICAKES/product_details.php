<?php
// Start session
session_start();

// Check if user is logged in
$logged_in = isset($_SESSION['user_id']);
$username = $logged_in ? $_SESSION['username'] : '';
$is_admin = $logged_in && isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;

// If user is admin, redirect to admin.php
if ($is_admin) {
    header("Location: admin.php");
    exit();
}

// Include database connection
require_once 'includes/db.php';

// Check if product ID is provided
if (!isset($_GET['id']) || !is_numeric($_GET['id'])) {
    header("Location: products.php");
    exit();
}

$product_id = $_GET['id'];

// Fetch product details
$product = null;
$related_products = [];

// Prepare statement to prevent SQL injection
$stmt = mysqli_prepare($conn, "SELECT * FROM products WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $product_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result && mysqli_num_rows($result) > 0) {
    $product = mysqli_fetch_assoc($result);
    
    // Fetch related products from the same category
    $category = $product['category'];
    $related_query = mysqli_prepare($conn, "SELECT * FROM products WHERE category = ? AND id != ? AND stock > 0 LIMIT 4");
    mysqli_stmt_bind_param($related_query, "si", $category, $product_id);
    mysqli_stmt_execute($related_query);
    $related_result = mysqli_stmt_get_result($related_query);
    
    if ($related_result && mysqli_num_rows($related_result) > 0) {
        while ($row = mysqli_fetch_assoc($related_result)) {
            $related_products[] = $row;
        }
    }
} else {
    // Product not found, redirect to products page
    header("Location: products.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($product['name']); ?> - BLASTICAKES & CRAFTS</title>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
        }
        
        header {
            background-color: #ff6b6b;
            color: white;
            padding: 10px 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
        }
        
        header h1 {
            margin: 0;
            font-size: 28px;
        }
        
        nav ul {
            list-style: none;
            display: flex;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            margin-left: 20px;
        }
        
        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        
        nav ul li a:hover {
            background-color: rgba(255,255,255,0.2);
        }
        
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 20px 0;
            margin-top: 50px;
        }
        
        /* Product details styles */
        .breadcrumb {
            margin: 20px 0;
            color: #666;
        }
        
        .breadcrumb a {
            color: #ff6b6b;
            text-decoration: none;
        }
        
        .breadcrumb a:hover {
            text-decoration: underline;
        }
        
        .product-details-container {
            display: flex;
            background-color: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin: 30px 0;
        }
        
        .product-image-container {
            flex: 1;
            padding: 30px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .product-image-container img {
            max-width: 100%;
            max-height: 400px;
            object-fit: contain;
            border-radius: 8px;
        }
        
        .product-info {
            flex: 1;
            padding: 30px;
            border-left: 1px solid #eee;
        }
        
        .product-category {
            display: inline-block;
            background-color: #f0f0f0;
            color: #666;
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 0.9em;
            margin-bottom: 15px;
            text-transform: capitalize;
        }
        
        .product-title {
            font-size: 2em;
            margin: 0 0 15px;
            color: #333;
        }
        
        .product-price {
            font-size: 1.8em;
            color: #ff6b6b;
            font-weight: bold;
            margin: 15px 0;
        }
        
        .product-description {
            color: #666;
            margin-bottom: 25px;
            line-height: 1.8;
        }
        
        .product-meta {
            margin-bottom: 25px;
        }
        
        .product-meta p {
            margin: 8px 0;
            color: #666;
        }
        
        .product-meta strong {
            color: #333;
        }
        
        .lead-time {
            color: #17a2b8;
            font-weight: bold;
        }
        
        .quantity-selector {
            display: flex;
            align-items: center;
            margin-bottom: 25px;
        }
        
        .quantity-selector label {
            margin-right: 15px;
            font-weight: bold;
            color: #333;
        }
        
        .quantity-selector input {
            width: 60px;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-align: center;
        }
        
        .btn {
            display: inline-block;
            background-color: #ff6b6b;
            color: white;
            padding: 12px 25px;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
            transition: background-color 0.3s;
            border: none;
            cursor: pointer;
            font-size: 1em;
        }
        
        .btn:hover {
            background-color: #ff5252;
        }
        
        .btn-secondary {
            background-color: #f0f0f0;
            color: #333;
            margin-left: 10px;
        }
        
        .btn-secondary:hover {
            background-color: #e0e0e0;
        }
        
        .section-title {
            text-align: center;
            margin: 40px 0 30px;
            color: #333;
            position: relative;
        }
        
        .section-title:after {
            content: '';
            display: block;
            width: 80px;
            height: 3px;
            background-color: #ff6b6b;
            margin: 15px auto 0;
        }
        
        /* Related products */
        .products-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 30px;
            margin-bottom: 40px;
        }
        
        .product-card {
            background-color: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .product-card .product-image {
            height: 200px;
            overflow: hidden;
        }
        
        .product-card .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.5s;
        }
        
        .product-card:hover .product-image img {
            transform: scale(1.05);
        }
        
        .product-card .product-details {
            padding: 20px;
        }
        
        .product-card .product-title {
            font-size: 1.2em;
            margin: 0 0 10px;
            color: #333;
        }
        
        .product-card .product-category {
            display: inline-block;
            background-color: #f0f0f0;
            color: #666;
            padding: 3px 10px;
            border-radius: 20px;
            font-size: 0.8em;
            margin-bottom: 10px;
            text-transform: capitalize;
        }
        
        .product-card .product-price {
            font-size: 1.3em;
            color: #ff6b6b;
            font-weight: bold;
            margin: 10px 0;
        }
        
        .product-card .product-actions {
            display: flex;
            justify-content: space-between;
            margin-top: 15px;
        }
        
        .product-card .view-btn {
            padding: 8px 15px;
            background-color: #f0f0f0;
            color: #333;
            text-decoration: none;
            border-radius: 4px;
            font-size: 0.9em;
            transition: background-color 0.3s;
        }
        
        .product-card .view-btn:hover {
            background-color: #e0e0e0;
        }
        
        .product-card .add-to-cart-btn {
            padding: 8px 15px;
            background-color: #ff6b6b;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-size: 0.9em;
            transition: background-color 0.3s;
            border: none;
            cursor: pointer;
        }
        
        .product-card .add-to-cart-btn:hover {
            background-color: #ff5252;
        }
        
        /* User dropdown menu */
        .user-dropdown {
            position: relative;
            display: inline-block;
        }
        
        .user-dropdown-btn {
            display: flex;
            align-items: center;
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .user-dropdown-btn:hover {
            background-color: rgba(255,255,255,0.2);
        }
        
        .user-dropdown-btn img {
            width: 25px;
            height: 25px;
            border-radius: 50%;
            margin-right: 8px;
            object-fit: cover;
        }
        
        .user-dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 180px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .user-dropdown-content a {
            color: #333;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }
        
        .user-dropdown-content a:hover {
            background-color: #f1f1f1;
        }
        
        .user-dropdown:hover .user-dropdown-content {
            display: block;
        }
        
        /* Notification styles */
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            padding: 15px 25px;
            background-color: #4CAF50;
            color: white;
            border-radius: 4px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            z-index: 1000;
            display: none;
            animation: fadeInOut 3s ease-in-out;
        }
        
        @keyframes fadeInOut {
            0% { opacity: 0; }
            10% { opacity: 1; }
            90% { opacity: 1; }
            100% { opacity: 0; }
        }
        
        /* Responsive adjustments */
        @media (max-width: 768px) {
            .product-details-container {
                flex-direction: column;
            }
            
            .product-image-container, .product-info {
                padding: 20px;
            }
            
            .product-info {
                border-left: none;
                border-top: 1px solid #eee;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>BLASTICAKES & CRAFTS</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="products.php">Products</a></li>
                                        <?php if ($logged_in): ?>
                        <li><a href="my_orders.php">My Orders</a></li>
                        <li><a href="cart.php">Cart</a></li>
                        <li class="user-dropdown">
                            <div class="user-dropdown-btn">
                                <?php
                                $user_id = $_SESSION['user_id'];
                                
                                $profile_query = "SELECT profile_picture FROM users WHERE id = ?";
                                
                                $stmt = mysqli_prepare($conn, $profile_query);
                                
                                mysqli_stmt_bind_param($stmt, "i", $user_id);
                                mysqli_stmt_execute($stmt);
                                $profile_result = mysqli_stmt_get_result($stmt);
                                $profile_pic = 'default_profile.png'; // Default image
                                
                                if ($profile_row = mysqli_fetch_assoc($profile_result)) {
                                    if (!empty($profile_row['profile_picture'])) {
                                        $profile_pic = $profile_row['profile_picture'];
                                    }
                                }
                                ?>
                                <img src="profile_images/<?php echo $profile_pic; ?>" alt="Profile">
                                <?php echo $username; ?>
                            </div>
                            
                            <div class="user-dropdown-content">
                                <a href="account.php"><i class="fas fa-user"></i> My Account</a>
                                <a href="my_orders.php"><i class="fas fa-shopping-bag"></i> My Orders</a>
                                <a href="change_password.php"><i class="fas fa-key"></i> Change Password</a>
                                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                            </div>
                        </li>
                    <?php else: ?>
                        <li><a href="login.php">Login</a></li>
                        <li><a href="signup.php">Sign Up</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>

    <div class="container">
        <!-- Breadcrumb navigation -->
        <div class="breadcrumb">
            <a href="index.php">Home</a> &gt; 
            <a href="products.php">Products</a> &gt; 
            <a href="products.php?category=<?php echo urlencode($product['category']); ?>"><?php echo ucfirst(htmlspecialchars($product['category'])); ?></a> &gt; 
            <?php echo htmlspecialchars($product['name']); ?>
        </div>

        <!-- Product Details Section -->
        <div class="product-details-container">
            <div class="product-image-container">
                <img src="images/<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
            </div>
            <div class="product-info">
                <span class="product-category"><?php echo htmlspecialchars(ucfirst($product['category'])); ?></span>
                <h1 class="product-title"><?php echo htmlspecialchars($product['name']); ?></h1>
                <p class="product-price">₱<?php echo number_format($product['price'], 2); ?></p>
                
                <div class="product-description">
                    <?php echo nl2br(htmlspecialchars($product['description'])); ?>
                </div>
                
                <div class="product-meta">
                    <p><strong>Availability:</strong> <?php echo $product['stock'] > 0 ? 'In Stock' : 'Out of Stock'; ?></p>
                    <?php if($product['stock'] > 0): ?>
                        <p><strong>Available Quantity:</strong> <?php echo $product['stock']; ?></p>
                    <?php endif; ?>
                    <?php if(isset($product['lead_time']) && !empty($product['lead_time'])): ?>
                        <p><span class="lead-time"><strong>Order at least <?php echo $product['lead_time']; ?> days before desired date</strong></span></p>
                    <?php endif; ?>
                </div>
                
                <?php if($product['stock'] > 0): ?>
                    <form id="addToCartForm" action="add_to_cart.php" method="post">
                        <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                        <input type="hidden" name="return_url" value="cart.php?added=1">
                        
                        <div class="quantity-selector">
                            <label for="quantity">Quantity:</label>
                            <input type="number" id="quantity" name="quantity" value="1" min="1" max="<?php echo $product['stock']; ?>">
                        </div>
                        
                        <?php if ($logged_in): ?>
                            <button type="submit" id="addToCartBtn" class="btn"><i class="fas fa-shopping-cart"></i> Add to Cart</button>
                            <a href="products.php" class="btn btn-secondary">Continue Shopping</a>
                        <?php else: ?>
                            <a href="login.php" class="btn"><i class="fas fa-sign-in-alt"></i> Login to Purchase</a>
                            <a href="products.php" class="btn btn-secondary">Continue Shopping</a>
                        <?php endif; ?>
                    </form>
                <?php else: ?>
                    <p style="color: #ff6b6b; font-weight: bold;">This product is currently out of stock.</p>
                    <a href="products.php" class="btn btn-secondary">Continue Shopping</a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Related Products Section -->
        <?php if (!empty($related_products)): ?>
            <h2 class="section-title">Related Products</h2>
            <div class="products-grid">
                <?php foreach ($related_products as $related): ?>
                    <div class="product-card">
                        <div class="product-image">
                            <img src="images/<?php echo htmlspecialchars($related['image']); ?>" alt="<?php echo htmlspecialchars($related['name']); ?>">
                        </div>
                        <div class="product-details">
                            <span class="product-category"><?php echo htmlspecialchars(ucfirst($related['category'])); ?></span>
                            <h3 class="product-title"><?php echo htmlspecialchars($related['name']); ?></h3>
                            <p class="product-price">₱<?php echo number_format($related['price'], 2); ?></p>
                            <div class="product-actions">
                                <a href="product_details.php?id=<?php echo $related['id']; ?>" class="view-btn">View Details</a>
                                <?php if ($logged_in): ?>
                                    <form action="add_to_cart.php" method="post" style="display:inline;">
                                        <input type="hidden" name="product_id" value="<?php echo $related['id']; ?>">
                                        <input type="hidden" name="quantity" value="1">
                                        <input type="hidden" name="return_url" value="cart.php?added=1">
                                        <button type="submit" class="add-to-cart-btn">Add to Cart</button>
                                    </form>
                                <?php else: ?>
                                    <a href="login.php" class="add-to-cart-btn">Login to Buy</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <!-- Notification element -->
    <div id="notification" class="notification"></div>
    
    <footer>
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> BLASTICAKES & CRAFTS. All rights reserved.</p>
        </div>
    </footer>

    <!-- Add jQuery for AJAX functionality -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        $(document).ready(function() {
            // Check for added parameter in URL
            <?php if (isset($_GET['added']) && $_GET['added'] == 1): ?>
                showNotification("Product added to cart successfully!");
            <?php endif; ?>
            
            // Function to show notification
            function showNotification(message, type = "success") {
                var notification = $("#notification");
                notification.text(message);
                
                if (type === "error") {
                    notification.css("background-color", "#ff6b6b");
                } else {
                    notification.css("background-color", "#4CAF50");
                }
                
                notification.css("display", "block");
                
                // Hide notification after 3 seconds
                setTimeout(function() {
                    notification.css("display", "none");
                }, 3000);
            }
        });
    </script>
</body>
</html>
