<?php
// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Include database connection
require_once 'includes/db.php';

// Get user info
$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;

// Get user data
$user_query = "SELECT * FROM users WHERE id = ?";
$stmt = mysqli_prepare($conn, $user_query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$user_result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($user_result);

// Initialize variables
$cart_items = [];
$total = 0;
$stock_error = false;
$out_of_stock_items = [];

// Check if cart exists and has items
if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
    $cart_items = $_SESSION['cart'];
    
    // Check stock availability and calculate total
    foreach ($cart_items as $id => $item) {
        // Get current stock from database
        $stock_query = "SELECT stock FROM products WHERE id = ?";
        $stmt = mysqli_prepare($conn, $stock_query);
        mysqli_stmt_bind_param($stmt, "i", $id);
        mysqli_stmt_execute($stmt);
        $stock_result = mysqli_stmt_get_result($stmt);
        $product = mysqli_fetch_assoc($stock_result);
        
        // Check if requested quantity exceeds available stock
        if ($item['quantity'] > $product['stock']) {
            $stock_error = true;
            $out_of_stock_items[] = [
                'name' => $item['name'],
                'requested' => $item['quantity'],
                'available' => $product['stock']
            ];
        }
        
        $total += $item['price'] * $item['quantity'];
    }
}

// Handle remove item from cart
if (isset($_GET['remove']) && isset($_SESSION['cart'][$_GET['remove']])) {
    unset($_SESSION['cart'][$_GET['remove']]);
    header("Location: cart.php");
    exit();
}

// Handle update quantity
if (isset($_POST['update_cart'])) {
    foreach ($_POST['quantity'] as $id => $quantity) {
        if (isset($_SESSION['cart'][$id])) {
            // Get current stock from database
            $stock_query = "SELECT stock FROM products WHERE id = ?";
            $stmt = mysqli_prepare($conn, $stock_query);
            mysqli_stmt_bind_param($stmt, "i", $id);
            mysqli_stmt_execute($stmt);
            $stock_result = mysqli_stmt_get_result($stmt);
            $product = mysqli_fetch_assoc($stock_result);
            
            // Ensure quantity doesn't exceed stock
            $quantity = (int)$quantity;
            if ($quantity > $product['stock']) {
                $quantity = $product['stock'];
            }
            
            $_SESSION['cart'][$id]['quantity'] = max(1, $quantity);
        }
    }
    header("Location: cart.php");
    exit();
}

// Handle clear cart
if (isset($_GET['clear'])) {
    $_SESSION['cart'] = [];
    header("Location: cart.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - BLASTICAKES & CRAFTS</title>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
        }
        
        header {
            background-color: #ff6b6b;
            color: white;
            padding: 10px 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
        }
        
        header h1 {
            margin: 0;
            font-size: 28px;
        }
        
        nav ul {
            list-style: none;
            display: flex;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            margin-left: 20px;
        }
        
        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        
        nav ul li a:hover {
            background-color: rgba(255,255,255,0.2);
        }
        
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 20px 0;
            margin-top: 50px;
        }
        
        /* User dropdown menu */
        .user-dropdown {
            position: relative;
            display: inline-block;
        }
        
        .user-dropdown-btn {
            display: flex;
            align-items: center;
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .user-dropdown-btn:hover {
            background-color: rgba(255,255,255,0.2);
        }
        
        .user-dropdown-btn img {
            width: 25px;
            height: 25px;
            border-radius: 50%;
            margin-right: 8px;
            object-fit: cover;
        }
        
        .user-dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 180px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .user-dropdown-content a {
            color: #333;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }
        
        .user-dropdown-content a:hover {
            background-color: #f1f1f1;
        }
        
        .user-dropdown:hover .user-dropdown-content {
            display: block;
        }
        
        /* Page specific styles */
        .page-title {
            color: #ff6b6b;
            margin-bottom: 30px;
            text-align: center;
            font-size: 2em;
        }
        
        .cart-container {
            background: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-top: 20px;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        th {
            background-color: #f2f2f2;
        }
        
        .product-img {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 4px;
        }
        
        .quantity-input {
            width: 60px;
            padding: 5px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-align: center;
        }
        
        .btn {
            display: inline-block;
            
            background-color: #ff6b6b;
            color: white;
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 14px;
        }
        
        .btn:hover {
            background-color: #ff5252;
        }
        
        .btn-danger {
            background-color: #e74c3c;
        }
        
        .btn-danger:hover {
            background-color: #c0392b;
        }
        
        .cart-actions {
            margin-top: 20px;
            display: flex;
            justify-content: space-between;
        }
        
        .cart-summary {
            margin-top: 20px;
            text-align: right;
        }
        
        .cart-total {
            font-size: 1.2em;
            font-weight: bold;
            margin: 10px 0;
        }
        
        .empty-cart {
            text-align: center;
            padding: 50px 0;
            color: #666;
        }
        
        .alert {
            padding: 10px 15px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
        }
        
        .stock-warning {
            color: #721c24;
            font-size: 0.9em;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>BLASTICAKES & CRAFTS</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="products.php">Products</a></li>
                    <li><a href="my_orders.php">My Orders</a></li>
                    <li><a href="cart.php">Cart</a></li>
                    <li class="user-dropdown">
                        <div class="user-dropdown-btn">
                            <?php 
                            // Get user profile picture
                            $profile_pic = !empty($user['profile_picture']) ? $user['profile_picture'] : 'default_profile.png';
                            ?>
                            <img src="profile_images/<?php echo $profile_pic; ?>" alt="Profile">
                            <?php echo $username; ?>
                        </div>
                        <div class="user-dropdown-content">
                            <a href="account.php"><i class="fas fa-user"></i> My Account</a>
                            <a href="my_orders.php"><i class="fas fa-shopping-bag"></i> My Orders</a>
                            <a href="change_password.php"><i class="fas fa-key"></i> Change Password</a>
                            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        </div>
                    </li>
                </ul>
            </nav>
        </div>
    </header>
    
    <div class="container">
        <h2>Shopping Cart</h2>
        
        <?php if (isset($_GET['added'])): ?>
            <div class="alert alert-success">
                Product added to cart successfully!
            </div>
        <?php endif; ?>
        
        <?php if ($stock_error): ?>
            <div class="alert alert-danger">
                <strong>Out of Stock Warning:</strong>
                <ul>
                    <?php foreach ($out_of_stock_items as $item): ?>
                        <li>
                            <?php echo $item['name']; ?> - You requested <?php echo $item['requested']; ?> but only <?php echo $item['available']; ?> are available.
                        </li>
                    <?php endforeach; ?>
                </ul>
                Please update your cart quantities before proceeding to checkout.
            </div>
        <?php endif; ?>
        
        <div class="cart-container">
            <?php if (!empty($cart_items)): ?>
                <form method="post" action="cart.php">
                    <table>
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Subtotal</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($cart_items as $id => $item): 
                                // Get current stock from database for display
                                $stock_query = "SELECT stock FROM products WHERE id = ?";
                                $stmt = mysqli_prepare($conn, $stock_query);
                                mysqli_stmt_bind_param($stmt, "i", $id);
                                mysqli_stmt_execute($stmt);
                                $stock_result = mysqli_stmt_get_result($stmt);
                                $product = mysqli_fetch_assoc($stock_result);
                                $available_stock = $product['stock'];
                                $exceeds_stock = $item['quantity'] > $available_stock;
                            ?>
                                <tr <?php echo $exceeds_stock ? 'style="background-color: #fff8f8;"' : ''; ?>>
                                    <td>
                                        <img src="images/<?php echo $item['image']; ?>" alt="<?php echo $item['name']; ?>" class="product-img">
                                        <?php echo $item['name']; ?>
                                        <?php if ($exceeds_stock): ?>
                                            <div class="stock-warning">
                                                Only <?php echo $available_stock; ?> in stock!
                                            </div>
                                        <?php endif; ?>
                                    </td>
                                    <td>₱<?php echo number_format($item['price'], 2); ?></td>
                                    <td>
                                        <input type="number" name="quantity[<?php echo $id; ?>]" value="<?php echo $item['quantity']; ?>" min="1" max="<?php echo $available_stock; ?>" class="quantity-input" 
                                        onchange="if(this.value > <?php echo $available_stock; ?>) { this.value = <?php echo $available_stock; ?>; alert('Maximum available stock is <?php echo $available_stock; ?>'); }">
                                    </td>
                                    <td>₱<?php echo number_format($item['price'] * $item['quantity'], 2); ?></td>
                                                                        <td>
                                        <a href="cart.php?remove=<?php echo $id; ?>" class="btn btn-danger">Remove</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    
                    <div class="cart-actions">
                        <div>
                            <button type="submit" name="update_cart" class="btn">Update Cart</button>
                            <a href="cart.php?clear=1" class="btn btn-danger">Clear Cart</a>
                            <a href="products.php" class="btn">Continue Shopping</a>
                        </div>
                        <div class="cart-summary">
                            <div class="cart-total">Total: ₱<?php echo number_format($total, 2); ?></div>
                            
                            <?php if (!$stock_error): ?>
                                <a href="checkout.php" class="btn">Proceed to Checkout</a>
                            <?php else: ?>
                                <button type="button" class="btn" style="background-color: #999; cursor: not-allowed;" disabled>Proceed to Checkout</button>
                            <?php endif; ?>
                        </div>
                    </div>
                </form>
            <?php else: ?>
                <div class="empty-cart">
                    <h3>Your cart is empty</h3>
                    <p>Looks like you haven't added any products to your cart yet.</p>
                    <a href="products.php" class="btn">Browse Products</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <footer>
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> BLASTICAKES & CRAFTS. All rights reserved.</p>
        </div>
    </footer>

    <script>
    // Additional JavaScript to enforce stock limits on quantity inputs
    document.addEventListener('DOMContentLoaded', function() {
        const quantityInputs = document.querySelectorAll('.quantity-input');
        
        quantityInputs.forEach(input => {
            input.addEventListener('input', function() {
                const max = parseInt(this.getAttribute('max'), 10);
                const value = parseInt(this.value, 10);
                
                if (value > max) {
                    this.value = max;
                    alert('Maximum available stock is ' + max);
                }
            });
        });
    });
    </script>
</body>
</html>
