<?php
// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Include database connection
require_once 'includes/db.php';

// Get user information
$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

// Get user data
$stmt = mysqli_prepare($conn, "SELECT * FROM users WHERE id = ?");
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($result);

// Initialize variables
$current_password = $new_password = $confirm_password = "";
$error = $success = "";

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $current_password = trim($_POST['current_password']);
    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST['confirm_password']);
    
    // Validate input
    if (empty($current_password) || empty($new_password) || empty($confirm_password)) {
        $error = "All fields are required";
    } elseif ($new_password !== $confirm_password) {
        $error = "New passwords do not match";
    } elseif (strlen($new_password) < 8) {
        $error = "Password must be at least 8 characters long";
    } else {
        // Get user's current password from database
        $user_id = $_SESSION['user_id'];
        $stmt = mysqli_prepare($conn, "SELECT plain_password FROM users WHERE id = ?");
        mysqli_stmt_bind_param($stmt, "i", $user_id);
        mysqli_stmt_execute($stmt);
        $result = mysqli_stmt_get_result($stmt);
        
        if (mysqli_num_rows($result) === 1) {
            $user = mysqli_fetch_assoc($result);
            
            // Compare with plain_password
            if ($current_password === $user['plain_password']) {
                // Hash new password
                $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                
                // Update password in database
                $update_stmt = mysqli_prepare($conn, "UPDATE users SET password = ?, plain_password = ? WHERE id = ?");
                mysqli_stmt_bind_param($update_stmt, "ssi", $hashed_password, $new_password, $user_id);
                
                if (mysqli_stmt_execute($update_stmt)) {
                    $success = "Password changed successfully!";
                    // Clear form fields after successful submission
                    $current_password = $new_password = $confirm_password = "";
                } else {
                    $error = "Error updating password: " . mysqli_error($conn);
                }
                
                mysqli_stmt_close($update_stmt);
            } else {
                $error = "Current password is incorrect";
            }
        } else {
            $error = "User not found";
        }
        
        mysqli_stmt_close($stmt);
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Password - BLASTICAKES & CRAFTS</title>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
        }
        
        header {
            background-color: #ff6b6b;
            color: white;
            padding: 10px 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
        }
        
        header h1 {
            margin: 0;
            font-size: 28px;
        }
        
        nav ul {
            list-style: none;
            display: flex;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            margin-left: 20px;
        }
        
        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        
        nav ul li a:hover {
            background-color: rgba(255,255,255,0.2);
        }
        
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 20px 0;
            margin-top: 50px;
        }
        
        /* User dropdown menu */
        .user-dropdown {
            position: relative;
            display: inline-block;
        }
        
        .user-dropdown-btn {
            display: flex;
            align-items: center;
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .user-dropdown-btn:hover {
            background-color: rgba(255,255,255,0.2);
        }
        
        .user-dropdown-btn img {
            width: 25px;
            height: 25px;
            border-radius: 50%;
            margin-right: 8px;
            object-fit: cover;
        }
        
        .user-dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 180px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .user-dropdown-content a {
            color: #333;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }
        
        .user-dropdown-content a:hover {
            background-color: #f1f1f1;
        }
        
        .user-dropdown:hover .user-dropdown-content {
            display: block;
        }
        
        /* Page specific styles */
        .page-title {
            color: #ff6b6b;
            margin-bottom: 30px;
            text-align: center;
            font-size: 2em;
        }
        
        .account-container {
            display: flex;
            gap: 30px;
            margin-top: 30px;
        }
        
        .account-sidebar {
            flex: 0 0 250px;
            background-color: white;
            border-radius: 8px;
            padding: 20px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            text-align: center;
        }
        
        .account-content {
            flex: 1;
            background-color: white;
            border-radius: 8px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .profile-picture {
            width: 120px;
            height: 120px;
            border-radius: 50%;
            object-fit: cover;
            margin: 0 auto 15px;
            border: 3px solid #ff6b6b;
        }
        
        .user-name {
            margin: 10px 0 5px;
            color: #333;
        }
        
        .user-email {
            color: #777;
            margin-bottom: 20px;
        }
        
        .account-menu {
            list-style: none;
            padding: 0;
            margin: 0;
            text-align: left;
        }
        
        .account-menu li {
            margin-bottom: 5px;
        }
        
        .account-menu a {
            display: block;
            padding: 10px 15px;
            color: #555;
            text-decoration: none;
            border-radius: 4px;
            transition: all 0.3s;
        }
        
        .account-menu a:hover, .account-menu a.active {
            background-color: #ffeded;
            color: #ff6b6b;
        }
        
        .account-menu a.active {
            font-weight: bold;
            border-left: 3px solid #ff6b6b;
        }
        
        .account-menu i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .section-title {
            color: #333;
            margin-top: 0;
            margin-bottom: 25px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: bold;
        }
        
        .form-control {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            border-color: #ff6b6b;
            outline: none;
        }
        
        .btn {
            display: inline-block;
            background-color: #ff6b6b;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .btn:hover {
            background-color: #ff5252;
        }
        
        .btn-secondary {
            background-color: #6c757d;
        }
        
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        /* Responsive design */
        @media (max-width: 768px) {
            .account-container {
                flex-direction: column;
            }
            
            .account-sidebar {
                flex: 0 0 auto;
                margin-bottom: 20px;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>BLASTICAKES & CRAFTS</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="products.php">Products</a></li>
                    <li><a href="my_orders.php">My Orders</a></li>
                    <li><a href="cart.php">Cart</a></li>
                    <li class="user-dropdown">
                        <div class="user-dropdown-btn">
                            <?php 
                            // Get user profile picture
                            $profile_pic = !empty($user['profile_picture']) ? $user['profile_picture'] : 'default_profile.png';
                            ?>
                            <img src="profile_images/<?php echo $profile_pic; ?>" alt="Profile">
                            <?php echo $username; ?>
                        </div>
                        <div class="user-dropdown-content">
                            <a href="account.php"><i class="fas fa-user"></i> My Account</a>
                            <a href="my_orders.php"><i class="fas fa-shopping-bag"></i> My Orders</a>
                            <a href="change_password.php"><i class="fas fa-key"></i> Change Password</a>
                            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        </div>
                    </li>
                </ul>
            </nav>
        </div>
    </header>
    
    <div class="container">
        <h1 class="page-title">Change Password</h1>
        
        <div class="account-container">
            <div class="account-sidebar">
                <?php 
                // Display profile picture
                $profile_pic = !empty($user['profile_picture']) ? $user['profile_picture'] : 'default_profile.png';
                ?>
                <img src="profile_images/<?php echo $profile_pic; ?>" alt="Profile Picture" class="profile-picture">
                <h2 class="user-name"><?php echo htmlspecialchars($user['username']); ?></h2>
                <p class="user-email"><?php echo htmlspecialchars($user['email']); ?></p>
                
                <ul class="account-menu">
                    <li><a href="account.php"><i class="fas fa-user"></i> Profile</a></li>
                    <li><a href="my_orders.php"><i class="fas fa-shopping-bag"></i> My Orders</a></li>
                    <li><a href="change_password.php" class="active"><i class="fas fa-key"></i> Change Password</a></li>
                    <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </div>
            
            <div class="account-content">
                <h2 class="section-title">Change Your Password</h2>
                
                <?php if (!empty($error)): ?>
                    <div class="alert alert-danger"><?php echo $error; ?></div>
                <?php endif; ?>
                
                <?php if (!empty($success)): ?>
                    <div class="alert alert-success"><?php echo $success; ?></div>
                <?php endif; ?>
                
                <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <div class="form-group">
                        <label for="current_password">Current Password*</label>
                                                <input type="password" class="form-control" id="current_password" name="current_password" value="<?php echo htmlspecialchars($current_password); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="new_password">New Password*</label>
                        <input type="password" class="form-control" id="new_password" name="new_password" value="<?php echo htmlspecialchars($new_password); ?>">
                        <small class="form-text text-muted">Password must be at least 8 characters long.</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="confirm_password">Confirm New Password*</label>
                        <input type="password" class="form-control" id="confirm_password" name="confirm_password" value="<?php echo htmlspecialchars($confirm_password); ?>">
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" class="btn">Change Password</button>
                    </div>
                    
                    <div class="form-group">
                        <p><small>* Required fields</small></p>
                    </div>
                </form>
                
                <div class="password-tips">
                    <h3>Password Security Tips</h3>
                    <ul>
                        <li>Use a minimum of 8 characters</li>
                        <li>Include both uppercase and lowercase letters</li>
                        <li>Include at least one number</li>
                        <li>Include at least one special character (e.g., !@#$%^&*)</li>
                        <li>Avoid using easily guessable information like birthdays or names</li>
                        <li>Don't reuse passwords across multiple sites</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    
    <footer>
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> BLASTICAKES & CRAFTS. All rights reserved.</p>
        </div>
    </footer>
    
    <script>
        // Password strength indicator (optional enhancement)
        document.getElementById('new_password').addEventListener('input', function() {
            const password = this.value;
            let strength = 0;
            
            // Check length
            if (password.length >= 8) strength += 1;
            
            // Check for lowercase and uppercase
            if (password.match(/[a-z]/) && password.match(/[A-Z]/)) strength += 1;
            
            // Check for numbers
            if (password.match(/\d/)) strength += 1;
            
            // Check for special characters
            if (password.match(/[^a-zA-Z\d]/)) strength += 1;
            
            // Update UI based on strength (you can add visual indicators here)
            console.log('Password strength:', strength);
        });
        
        // Confirm password match check
        document.getElementById('confirm_password').addEventListener('input', function() {
            const newPassword = document.getElementById('new_password').value;
            const confirmPassword = this.value;
            
            if (newPassword === confirmPassword) {
                this.setCustomValidity('');
            } else {
                this.setCustomValidity('Passwords do not match');
            }
        });
    </script>
</body>
</html>
