<?php
session_start();

// Database connection
$conn = mysqli_connect("localhost", "root", "", "cake_shop");
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Initialize variables
$name = '';
$description = '';
$price = '';
$stock = '';
$category = '';
$delivery_date = '';
$errors = [];
$success_message = '';
$categories = ['cake', 'craft'];

// Process form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Validate and sanitize inputs
    $name = trim($_POST['name'] ?? '');
    $description = trim($_POST['description'] ?? '');
    $price = isset($_POST['price']) ? filter_var($_POST['price'], FILTER_VALIDATE_FLOAT) : false;
    $stock = isset($_POST['stock']) ? filter_var($_POST['stock'], FILTER_VALIDATE_INT) : false;
    $category = trim($_POST['category'] ?? '');
    $delivery_date = trim($_POST['delivery_date'] ?? '');
    
    // Validation
    if (empty($name)) {
        $errors[] = "Product name is required";
    }
    
    if (empty($description)) {
        $errors[] = "Description is required";
    }
    
    if ($price === false || $price <= 0) {
        $errors[] = "Valid price is required";
    }
    
    if ($stock === false || $stock < 0) {
        $errors[] = "Valid stock quantity is required";
    }
    
    if (empty($category)) {
        $errors[] = "Category is required";
    }
    
    if (empty($delivery_date)) {
        $errors[] = "Delivery date is required";
    }
    
    // Handle file upload
    $file_name = '';
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $file_name = time() . '_' . basename($_FILES['image']['name']);
        $upload_dir = 'images/';
        
        // Create directory if it doesn't exist
        if (!is_dir($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $upload_path = $upload_dir . $file_name;
        
        if (!move_uploaded_file($_FILES['image']['tmp_name'], $upload_path)) {
            $errors[] = "Failed to upload image";
        }
    } else {
        $errors[] = "Product image is required";
    }
    
    // If no errors, insert into database
    if (empty($errors)) {
        $delivery_datetime = $delivery_date . ' 00:00:00'; // Add time component
        
        $sql = "INSERT INTO products (name, description, price, stock, category, delivery_datetime, image) 
                VALUES (?, ?, ?, ?, ?, ?, ?)";
        
        $stmt = mysqli_prepare($conn, $sql);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, "sssisss", $name, $description, $price, $stock, $category, $delivery_datetime, $file_name);
            
            if (mysqli_stmt_execute($stmt)) {
                $success_message = "Product added successfully!";
                // Reset form fields after successful submission
                $name = $description = $price = $stock = $category = $delivery_date = '';
            } else {
                $errors[] = "Error: " . mysqli_stmt_error($stmt);
            }
            
            mysqli_stmt_close($stmt);
        } else {
            $errors[] = "Error: " . mysqli_error($conn);
        }
    }
}
?>

<div class="form-container">
    <?php if (!empty($errors)): ?>
        <div class="error-message">
            <ul><?php foreach ($errors as $error): ?><li><?php echo htmlspecialchars($error); ?></li><?php endforeach; ?></ul>
        </div>
    <?php endif; ?>
    <?php if (!empty($success_message)): ?>
        <div class="success-message"><?php echo htmlspecialchars($success_message); ?></div>
    <?php endif; ?>
    <form action="add_product.php" method="post" enctype="multipart/form-data">
        <div class="form-group">
            <label for="name">Product Name:</label>
            <input type="text" id="name" name="name" value="<?php echo htmlspecialchars($name); ?>" required>
        </div>
        <div class="form-group">
            <label for="description">Description:</label>
            <textarea id="description" name="description" required><?php echo htmlspecialchars($description); ?></textarea>
        </div>
        <div class="form-group">
            <label for="price">Price (₱):</label>
            <input type="number" id="price" name="price" step="0.01" min="0" value="<?php echo htmlspecialchars($price); ?>" required>
        </div>
        <div class="form-group">
            <label for="stock">Stock Quantity:</label>
            <input type="number" id="stock" name="stock" min="0" value="<?php echo htmlspecialchars($stock); ?>" required>
        </div>
        <div class="form-group">
            <label for="category">Category:</label>
            <select id="category" name="category" required>
                <option value="">Select Category</option>
                <?php foreach ($categories as $cat): ?>
                    <option value="<?php echo $cat; ?>" <?php if ($category === $cat) echo 'selected'; ?>>
                        <?php echo ucfirst($cat); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group">
            <label for="delivery_date">Delivery Date:</label>
            <input type="date" id="delivery_date" name="delivery_date" value="<?php echo htmlspecialchars($delivery_date); ?>" required>
            <div class="delivery-note">
                Order at least <input type="number" id="min_days" name="min_days" min="1" value="5" style="width: 40px; text-align: center;"> days before desired date
            </div>
        </div>
        <div class="form-group">
            <label for="image">Product Image:</label>
            <input type="file" id="image" name="image" accept=".jpg,.jpeg,.png,.gif" required>
            <div class="preview-container">
                <img id="imagePreview" alt="Image Preview" />
            </div>
        </div>
        <div class="form-actions">
            <button type="submit" class="btn">Add Product</button>
            <a href="admin.php" class="btn btn-secondary">Cancel</a>
        </div>
    </form>
</div>

<script>
    // Image preview functionality
    document.getElementById('image').addEventListener('change', function(e) {
        const preview = document.getElementById('imagePreview');
        const file = e.target.files[0];
        
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                preview.src = e.target.result;
                preview.style.display = 'block';
            }
            reader.readAsDataURL(file);
        }
    });
</script>
