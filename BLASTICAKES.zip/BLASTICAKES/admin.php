<?php
session_start();
require_once 'includes/db.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];

// Handle product deletion
if (isset($_POST['delete_product']) && isset($_POST['product_id'])) {
    $product_id = mysqli_real_escape_string($conn, $_POST['product_id']);
    
    // Check if product exists
    $check_sql = "SELECT * FROM products WHERE id = ?";
    $check_stmt = mysqli_prepare($conn, $check_sql);
    mysqli_stmt_bind_param($check_stmt, "i", $product_id);
    mysqli_stmt_execute($check_stmt);
    $check_result = mysqli_stmt_get_result($check_stmt);
    
    if (mysqli_num_rows($check_result) > 0) {
        // Delete the product
        $delete_sql = "DELETE FROM products WHERE id = ?";
        $delete_stmt = mysqli_prepare($conn, $delete_sql);
        mysqli_stmt_bind_param($delete_stmt, "i", $product_id);
        
        if (mysqli_stmt_execute($delete_stmt)) {
            $success_message = "Product deleted successfully!";
        } else {
            $error_message = "Error deleting product: " . mysqli_error($conn);
        }
    } else {
        $error_message = "Product not found!";
    }
}

// Get date range for revenue filter
$start_date = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$end_date = isset($_GET['end_date']) ? $_GET['end_date'] : '';

// Default to today if no dates are provided
if (empty($start_date)) {
    $start_date = date('Y-m-d');
}
if (empty($end_date)) {
    $end_date = date('Y-m-d');
}

// Get total number of orders
$orders_sql = "SELECT COUNT(*) as total FROM orders";
$orders_result = mysqli_query($conn, $orders_sql);
$total_orders = mysqli_fetch_assoc($orders_result)['total'];

// Get total number of products
$products_sql = "SELECT COUNT(*) as total FROM products";
$products_result = mysqli_query($conn, $products_sql);
$total_products = mysqli_fetch_assoc($products_result)['total'];

// Get total number of users
$users_sql = "SELECT COUNT(*) as total FROM users WHERE is_admin = 0";
$users_result = mysqli_query($conn, $users_sql);
$total_users = mysqli_fetch_assoc($users_result)['total'];

// Get total revenue with date filter
$revenue_sql = "SELECT SUM(total_amount) as total FROM orders WHERE status != 'Cancelled'";
if (!empty($start_date) && !empty($end_date)) {
    $revenue_sql .= " AND DATE(order_date) BETWEEN ? AND ?";
}
$stmt = mysqli_prepare($conn, $revenue_sql);
if (!empty($start_date) && !empty($end_date)) {
    mysqli_stmt_bind_param($stmt, "ss", $start_date, $end_date);
}
mysqli_stmt_execute($stmt);
$revenue_result = mysqli_stmt_get_result($stmt);
$total_revenue = mysqli_fetch_assoc($revenue_result)['total'] ?? 0;

// Get recent orders
$recent_orders_sql = "SELECT o.*, u.username FROM orders o
                      JOIN users u ON o.user_id = u.id
                      ORDER BY o.order_date DESC
                      LIMIT 5";
$recent_orders_result = mysqli_query($conn, $recent_orders_sql);

// Get orders by status
$status_sql = "SELECT status, COUNT(*) as count FROM orders GROUP BY status";
$status_result = mysqli_query($conn, $status_sql);
$status_counts = [];
if ($status_result) {
    while ($row = mysqli_fetch_assoc($status_result)) {
        $status_counts[$row['status']] = $row['count'];
    }
}

// Get top selling products
$top_products_sql = "SELECT p.id, p.name, p.image, SUM(oi.quantity) as total_sold
                     FROM products p
                     JOIN order_items oi ON p.id = oi.product_id
                     JOIN orders o ON oi.order_id = o.id
                     WHERE o.status != 'Cancelled'
                     GROUP BY p.id
                     ORDER BY total_sold DESC
                     LIMIT 5";
$top_products_result = mysqli_query($conn, $top_products_sql);

// Get recent reviews
$reviews_sql = "SELECT r.*, o.id as order_id, u.username, p.name as product_name
                FROM reviews r
                JOIN orders o ON r.order_id = o.id
                JOIN users u ON r.user_id = u.id
                JOIN order_items oi ON o.id = oi.order_id
                JOIN products p ON oi.product_id = p.id
                GROUP BY r.id
               ORDER BY r.created_at DESC
                LIMIT 5";
$reviews_result = mysqli_query($conn, $reviews_sql);

// Get all products for management
$all_products_sql = "SELECT * FROM products ORDER BY id DESC LIMIT 10";
$all_products_result = mysqli_query($conn, $all_products_sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - BLASTICAKES & CRAFTS</title>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <!-- Chart.js for charts -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f4f6f9;
        }
        header {
            background-color: #343a40;
            color: white;
            padding: 1rem;
        }
        .container {
            width: 90%;
            margin: 0 auto;
            padding: 20px;
        }
        nav {
            float: right;
        }
        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
        }
        nav li {
            display: inline;
            margin-left: 15px;
        }
        nav a {
            color: white;
            text-decoration: none;
        }
        h2 {
            color: #333;
            margin-top: 20px;
        }
        .btn {
            display: inline-block;
            background-color: #007bff;
            color: white;
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 14px;
        }
        .btn:hover {
            background-color: #0069d9;
        }
        .btn-danger {
            background-color: #dc3545;
        }
        .btn-danger:hover {
            background-color: #c82333;
        }
        .dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
            gap: 20px;
            margin-top: 20px;
        }
        .card {
            background-color: white;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        .card-title {
            margin: 0;
            font-size: 18px;
            color: #333;
        }
        .card-icon {
            font-size: 24px;
            color: #007bff;
        }
        .stat-card {
            text-align: center;
        }
        .stat-value {
            font-size: 28px;
            font-weight: bold;
            color: #333;
            margin: 10px 0;
        }
            
        .stat-label {
            color: #6c757d;
            font-size: 14px;
        }
        .chart-container {
            position: relative;
            height: 300px;
            width: 100%;
        }
        .orders-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        .orders-table th, .orders-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .orders-table th {
            background-color: #f8f9fa;
            color: #495057;
        }
        .orders-table tr:hover {
            background-color: #f8f9fa;
        }
        .order-status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }
        .status-pending {
            background-color: #ffeeba;
            color: #856404;
        }
        .status-processing {
            background-color: #b8daff;
            color: #004085;
        }
        .status-completed {
            background-color: #c3e6cb;
            color: #155724;
        }
        .status-cancelled {
            background-color: #f5c6cb;
            color: #721c24;
        }
        .product-list {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(150px, 1fr));
            gap: 15px;
            margin-top: 10px;
        }
        .product-card {
            background-color: #f8f9fa;
            border-radius: 5px;
            padding: 10px;
            text-align: center;
        }
        .product-image {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 4px;
            margin: 0 auto 10px;
        }
        .product-name {
            font-size: 14px;
            font-weight: bold;
            margin-bottom: 5px;
        }
        .product-sold {
            font-size: 12px;
            color: #6c757d;
        }
        .view-all {
            display: block;
            text-align: center;
            margin-top: 15px;
            color: #007bff;
            text-decoration: none;
        }
        .view-all:hover {
            text-decoration: underline;
        }
        .grid-span-2 {
            grid-column: span 2;
        }
        .recent-reviews {
            margin-top: 30px;
        }
        .reviews-list {
            margin-top: 15px;
        }
        .review-card {
            background-color: white;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 15px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        .review-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 10px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        .review-rating i {
            color: #ffb300;
            margin-right: 2px;
        }
        .review-meta {
            color: #777;
            font-size: 12px;
        }
        .review-content {
            margin-bottom: 10px;
        }
        .review-footer {
            text-align: right;
        }
        .review-footer a {
            color: #007bff;
            text-decoration: none;
            font-size: 14px;
        }
        .review-footer a:hover {
            text-decoration: underline;
        }
        .date-filter {
            margin-bottom: 20px;
            padding: 15px;
            background-color: white;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .date-filter form {
            display: flex;
            align-items: center;
            gap: 10px;
            flex-wrap: wrap;
        }
        .date-filter label {
            font-weight: bold;
            margin-right: 5px;
        }
        .date-filter input[type="date"] {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 4px;
        }
        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border-color: #c3e6cb;
        }
        .alert-danger {
            color: #721c24;
            background-color: #f8d7da;
            border-color: #f5c6cb;
        }
        .product-management {
            margin-top: 30px;
        }
        .product-table {
            width: 100%;
            border-collapse: collapse;
        }
        .product-table th, .product-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .product-table th {
            background-color: #f8f9fa;
            color: #495057;
        }
        .product-table img {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 4px;
        }
        .modal {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0,0,0,0.5);
        }
        .modal-content {
            background-color: white;
            margin: 15% auto;
            padding: 20px;
            border-radius: 5px;
            width: 400px;
                        max-width: 80%;
            box-shadow: 0 5px 15px rgba(0,0,0,0.3);
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        .modal-title {
            margin: 0;
            font-size: 18px;
            color: #333;
        }
        .close {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
        }
        .close:hover {
            color: #333;
        }
        .modal-body {
            margin-bottom: 20px;
        }
        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>BLASTICAKES & CRAFTS Admin</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="admin.php">Dashboard</a></li>
                    <li><a href="add_product.php">Products</a></li>
                    <li><a href="admin_orders.php">Orders</a></li>
                    <li><a href="admin_users.php">Users</a></li>
                    <li><a href="logout.php">Logout (<?php echo $username; ?>)</a></li>
                </ul>
            </nav>
        </div>
    </header>
    
    <div class="container">
        <h2>Admin Dashboard</h2>
        
        <?php if (isset($success_message)): ?>
            <div class="alert alert-success">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>
        
        <?php if (isset($error_message)): ?>
            <div class="alert alert-danger">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
        
        <!-- Date Filter for Revenue -->
        <div class="date-filter">
            <form action="admin.php" method="GET">
                <label for="start_date">Revenue From:</label>
                <input type="date" id="start_date" name="start_date" value="<?php echo $start_date; ?>">
                
                <label for="end_date">To:</label>
                <input type="date" id="end_date" name="end_date" value="<?php echo $end_date; ?>">
                
                <button type="submit" class="btn">Filter</button>
                <a href="admin.php" class="btn" style="background-color: #6c757d;">Reset</a>
            </form>
        </div>
        
        <div class="dashboard">
            <!-- Stats Cards -->
            <div class="card stat-card">
                <div class="card-icon">
                    <i class="fas fa-shopping-cart"></i>
                </div>
                <div class="stat-value"><?php echo $total_orders; ?></div>
                <div class="stat-label">Total Orders</div>
            </div>
            
            <div class="card stat-card">
                <div class="card-icon">
                    <i class="fas fa-birthday-cake"></i>
                </div>
                <div class="stat-value"><?php echo $total_products; ?></div>
                <div class="stat-label">Products</div>
            </div>
            
            <div class="card stat-card">
                <div class="card-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-value"><?php echo $total_users; ?></div>
                <div class="stat-label">Customers</div>
            </div>
            
            <div class="card stat-card">
                <div class="card-icon">
                    <i class="fas fa-money-bill-wave"></i>
                </div>
                <div class="stat-value">₱<?php echo number_format($total_revenue, 2); ?></div>
                <div class="stat-label">
                    Total Revenue
                    <?php if (!empty($start_date) && !empty($end_date)): ?>
                        <br><small>(<?php echo date('M j, Y', strtotime($start_date)); ?> - <?php echo date('M j, Y', strtotime($end_date)); ?>)</small>
                    <?php endif; ?>
                    
                </div>
            </div>
            
            <!-- Orders by Status Chart -->
            <div class="card grid-span-2">
                <div class="card-header">
                    <h3 class="card-title">Orders by Status</h3>
                </div>
                <div class="chart-container">
                    <canvas id="ordersChart"></canvas>
                </div>
            </div>
            
            <!-- Recent Orders -->
            <div class="card grid-span-2">
                <div class="card-header">
                    <h3 class="card-title">Recent Orders</h3>
                </div>
                <?php if ($recent_orders_result && mysqli_num_rows($recent_orders_result) > 0): ?>
                    <table class="orders-table">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Customer</th>
                                <th>Date</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($order = mysqli_fetch_assoc($recent_orders_result)): ?>
                                <tr>
                                    <td>#<?php echo $order['id']; ?></td>
                                    <td><?php echo htmlspecialchars($order['username']); ?></td>
                                    <td><?php echo date('M j, Y', strtotime($order['order_date'])); ?></td>
                                    <td>₱<?php echo number_format($order['total_amount'], 2); ?></td>
                                    <td>
                                        <span class="order-status status-<?php echo strtolower($order['status']); ?>">
                                            <?php echo $order['status']; ?>
                                        </span>
                                    </td>
                                    <td>
                                        <a href="admin_orders.php?order_id=<?php echo $order['id']; ?>" class="btn">View</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    <a href="admin_orders.php" class="view-all">View All Orders</a>
                <?php else: ?>
                    <p>No recent orders.</p>
                <?php endif; ?>
            </div>
            
            <!-- Top Selling Products -->
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Top Selling Products</h3>
                </div>
                <?php if ($top_products_result && mysqli_num_rows($top_products_result) > 0): ?>
                    <div class="product-list">
                        <?php while ($product = mysqli_fetch_assoc($top_products_result)): ?>
                            <div class="product-card">
                                <img src="images/<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>" class="product-image">
                                <div class="product-name"><?php echo htmlspecialchars($product['name']); ?></div>
                                <div class="product-sold"><?php echo $product['total_sold']; ?> sold</div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                    <a href="admin_products.php" class="view-all">View All Products</a>
                <?php else: ?>
                    <p>No product sales data available.</p>
                <?php endif; ?>
            </div>
            
            <!-- Recent Reviews -->
            <div class="card grid-span-2">
                <div class="card-header">
                    <h3 class="card-title">Recent Customer Reviews</h3>
                </div>
                
                <?php if ($reviews_result && mysqli_num_rows($reviews_result) > 0): ?>
                    <div class="reviews-list">
                        <?php while ($review = mysqli_fetch_assoc($reviews_result)): ?>
                            <div class="review-card">
                                <div class="review-header">
                                    <div class="review-rating">
                                        <?php for ($i = 1; $i <= 5; $i++): ?>
                                            <i class="fas fa-star<?php echo $i <= $review['rating'] ? '' : '-o'; ?>"></i>
                                        <?php endfor; ?>
                                    </div>
                                    <div class="review-meta">
                                        by <?php echo htmlspecialchars($review['username']); ?> on 
                                        <?php echo date('M j, Y', strtotime($review['created_at'])); ?>
                                    </div>
                                </div>
                                <div class="review-content">
                                    <p><?php echo htmlspecialchars($review['comment']); ?></p>
                                </div>
                                <div class="review-footer">
                                    <a href="admin_orders.php?order_id=<?php echo $review['order_id']; ?>">
                                        View Order #<?php echo $review['order_id']; ?>
                                    </a>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php else: ?>
                    <p>No reviews yet.</p>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Product Management Section -->
        <div class="product-management">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Product Management</h3>
                    <a href="add_product.php" class="btn">Add New Product</a>
                </div>
                
                <?php if ($all_products_result && mysqli_num_rows($all_products_result) > 0): ?>
                    <table class="product-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Image</th>
                                <th>Name</th>
                                <th>Price</th>
                                <th>Category</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($product = mysqli_fetch_assoc($all_products_result)): ?>
                                <tr>
                                    <td><?php echo $product['id']; ?></td>
                                    <td><img src="images/<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>"></td>
                                    <td><?php echo htmlspecialchars($product['name']); ?></td>
                                    <td>₱<?php echo number_format($product['price'], 2); ?></td>
                                    <td><?php echo htmlspecialchars($product['category']); ?></td>
                                    <td>
                                        <a href="edit_product.php?id=<?php echo $product['id']; ?>" class="btn">Edit</a>
                                        <button class="btn btn-danger" onclick="confirmDelete(<?php echo $product['id']; ?>, '<?php echo htmlspecialchars($product['name']); ?>')">Delete</button>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    <a href="add_product.php" class="view-all">Manage All Products</a>
                <?php else: ?>
                    <p>No products available.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    
    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title">Confirm Delete</h3>
                <span class="close" onclick="closeModal()">&times;</span>
            </div>
            <div class="modal-body">
                <p>Are you sure you want to delete the product: <span id="productName"></span>?</p>
                <p>This action cannot be undone.</p>
            </div>
            <div class="modal-footer">
                <form method="POST" action="admin.php">
                    <input type="hidden" name="product_id" id="deleteProductId">
                    <button type="button" class="btn" style="background-color: #6c757d;" onclick="closeModal()">Cancel</button>
                    <button type="submit" name="delete_product" class="btn btn-danger">Delete</button>
                </form>
            </div>
        </div>
    </div>
    
    <script>
        // Orders by Status Chart
        const statusLabels = <?php echo json_encode(array_keys($status_counts)); ?>;
        const statusData = <?php echo json_encode(array_values($status_counts)); ?>;
        const statusColors = {
            'Pending': '#ffc107',
            'Processing': '#007bff',
            'Completed': '#28a745',
            'Cancelled': '#dc3545'
        };
        
        const ctx = document.getElementById('ordersChart').getContext('2d');
        new Chart(ctx, {
            type: 'doughnut',
            data: {
                labels: statusLabels,
                datasets: [{
                    data: statusData,
                    backgroundColor: statusLabels.map(label => statusColors[label] || '#6c757d'),
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        position: 'right',
                    }
                }
            }
        });
        
        // Delete confirmation modal
        const modal = document.getElementById('deleteModal');
        
        function confirmDelete(productId, productName) {
            document.getElementById('productName').textContent = productName;
            document.getElementById('deleteProductId').value = productId;
            modal.style.display = 'block';
        }
        
        function closeModal() {
            modal.style.display = 'none';
        }
        
        // Close modal when clicking outside of it
        window.onclick = function(event) {
            if (event.target == modal) {
                closeModal();
            }
        }
    </script>
</body>
</html>
