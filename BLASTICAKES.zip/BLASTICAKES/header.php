<?php
// Add this to your header.php file or directly to pages that include the header

// Check for unread notifications if user is logged in
$notification_count = 0;
if (isset($_SESSION['user_id']) && !$is_admin) {
    $user_id = $_SESSION['user_id'];
    $notification_sql = "SELECT COUNT(*) as count FROM notifications WHERE user_id = $user_id AND is_read = 0";
    $notification_result = mysqli_query($conn, $notification_sql);
    
    if ($notification_result) {
        $row = mysqli_fetch_assoc($notification_result);
        $notification_count = $row['count'];
    }
}
?>

<!-- Then in your navigation menu: -->
<li>
    <a href="my_orders.php">
        My Orders
        <?php if ($notification_count > 0): ?>
            <span class="notification-badge"><?php echo $notification_count; ?></span>
        <?php endif; ?>
    </a>
</li>
