<?php
// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Get user info
$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;

// Include database connection
require_once 'includes/db.php';

// Get user data
$user_query = "SELECT * FROM users WHERE id = ?";
$stmt = mysqli_prepare($conn, $user_query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$user_result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($user_result);

// Get user's orders
$orders = [];
$sql = "SELECT * FROM orders WHERE user_id = $user_id ORDER BY order_date DESC";
$result = mysqli_query($conn, $sql);
if ($result && mysqli_num_rows($result) > 0) {
    while ($row = mysqli_fetch_assoc($result)) {
        // Get order items for this order
        $order_items_sql = "SELECT oi.*, p.name, p.image FROM order_items oi 
                           JOIN products p ON oi.product_id = p.id 
                           WHERE oi.order_id = {$row['id']}";
        $items_result = mysqli_query($conn, $order_items_sql);
        $items = [];
        if ($items_result && mysqli_num_rows($items_result) > 0) {
            while ($item = mysqli_fetch_assoc($items_result)) {
                $items[] = $item;
            }
        }
        $row['items'] = $items;
        $orders[] = $row;
    }
}

// Check for notifications
$notifications = [];
$notification_sql = "SELECT * FROM notifications WHERE user_id = $user_id AND is_read = 0 ORDER BY created_at DESC";
$notification_result = mysqli_query($conn, $notification_sql);
if ($notification_result && mysqli_num_rows($notification_result) > 0) {
    while ($row = mysqli_fetch_assoc($notification_result)) {
        $notifications[] = $row;
    }
}

// Mark notifications as read if viewing this page
if (!empty($notifications)) {
    mysqli_query($conn, "UPDATE notifications SET is_read = 1 WHERE user_id = $user_id");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Orders - BLASTICAKES & CRAFTS</title>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
        }
        
        header {
            background-color: #ff6b6b;
            color: white;
            padding: 10px 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
        }
        
        header h1 {
            margin: 0;
            font-size: 28px;
        }
        
        nav ul {
            list-style: none;
            display: flex;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            margin-left: 20px;
        }
        
        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        
        nav ul li a:hover {
            background-color: rgba(255,255,255,0.2);
        }
        
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 20px 0;
            margin-top: 50px;
        }
        
        /* User dropdown menu */
        .user-dropdown {
            position: relative;
            display: inline-block;
        }
        
        .user-dropdown-btn {
            display: flex;
            align-items: center;
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .user-dropdown-btn:hover {
            background-color: rgba(255,255,255,0.2);
        }
        
        .user-dropdown-btn img {
            width: 25px;
            height: 25px;
            border-radius: 50%;
            margin-right: 8px;
            object-fit: cover;
        }
        
        .user-dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 180px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .user-dropdown-content a {
            color: #333;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }
        
        .user-dropdown-content a:hover {
            background-color: #f1f1f1;
        }
        
        .user-dropdown:hover .user-dropdown-content {
            display: block;
        }
        
        /* Page specific styles */
        .page-title {
            color: #ff6b6b;
            margin-bottom: 30px;
            text-align: center;
            font-size: 2em;
        }
        
        h2 {
            color: #333;
            margin-top: 20px;
        }
        
        .btn {
            display: inline-block;
            background-color: #ff6b6b;
            color: white;
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            margin-right: 5px;
        }
        
        .btn:hover {
            background-color: #ff5252;
        }
        
        .btn-edit {
            background-color: #4CAF50;
        }
        
        .btn-edit:hover {
            background-color: #45a049;
        }
        
        .btn-cancel {
            background-color: #f44336;
        }
        
        .btn-cancel:hover {
            background-color: #d32f2f;
        }
        
        .btn-delete {
            background-color: #9e9e9e;
        }
        
        .btn-delete:hover {
            background-color: #757575;
        }
        
        .orders-container {
            margin-top: 20px;
        }
        
        .order-card {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
            overflow: hidden;
        }
        
        .order-header {
            background-color: #f5f5f5;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid #eee;
        }
        
        .order-id {
            font-weight: bold;
            font-size: 16px;
        }
        
        .order-date {
            color: #666;
            font-size: 14px;
        }
        
        .order-body {
            padding: 20px;
        }
        
        .order-details {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            margin-bottom: 15px;
        }
        
        .order-detail {
            flex-basis: 48%;
            margin-bottom: 10px;
        }
        
        .order-detail-label {
            font-weight: bold;
            color: #666;
            font-size: 14px;
        }
        
        .order-detail-value {
            font-size: 16px;
        }
        
        .order-status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }
        
        .status-pending {
            background-color: #ffeeba;
            color: #856404;
        }
        
        .status-processing {
            background-color: #b8daff;
            color: #004085;
        }
        
        .status-completed {
            background-color: #c3e6cb;
            color: #155724;
        }
        
        .status-cancelled {
            background-color: #f5c6cb;
            color: #721c24;
        }
        
        .order-actions {
            margin-top: 15px;
            text-align: right;
        }
        
        .empty-state {
            text-align: center;
            padding: 40px 20px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin: 30px 0;
        }
        
        .empty-state i {
            font-size: 50px;
            color: #ddd;
            margin-bottom: 20px;
        }
        
        .empty-state h3 {
            color: #666;
            margin-bottom: 10px;
        }
        
        .empty-state p {
            color: #999;
            margin-bottom: 20px;
        }
        
        .notification-badge {
            display: inline-block;
            background-color: #ff6b6b;
            color: white;
            border-radius: 50%;
            width: 20px;
            height: 20px;
            text-align: center;
            line-height: 20px;
            font-size: 12px;
            margin-left: 5px;
        }
        
        .notifications-container {
            margin-bottom: 30px;
        }
        
        .notification {
            background-color: #fff8e1;
            border-left: 4px solid #ffb300;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 4px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
        }
        
        .notification-title {
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .notification-time {
            color: #999;
            font-size: 12px;
            margin-top: 5px;
        }
        
        /* Product list styles */
        .order-products {
            margin-top: 15px;
            border-top: 1px solid #eee;
            padding-top: 15px;
        }
        
        .order-products-title {
            font-weight: bold;
            margin-bottom: 10px;
            color: #666;
        }
        
        .product-list {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .product-item {
            display: flex;
            align-items: center;
            padding: 8px 0;
            border-bottom: 1px dashed #eee;
        }
        
        .product-item:last-child {
            border-bottom: none;
        }
        
        .product-image {
            width: 40px;
            height: 40px;
            border-radius: 4px;
            object-fit: cover;
            margin-right: 10px;
        }
        
        .product-name {
            flex-grow: 1;
        }
        
        .product-quantity {
            color: #666;
            margin-left: 10px;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>BLASTICAKES & CRAFTS</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="products.php">Products</a></li>
                    <li><a href="my_orders.php">My Orders</a></li>
                    <li><a href="cart.php">Cart</a></li>
                    <li class="user-dropdown">
                        <div class="user-dropdown-btn">
                            <?php 
                            // Get user profile picture
                            $profile_pic = !empty($user['profile_picture']) ? $user['profile_picture'] : 'default_profile.png';
                            ?>
                            <img src="profile_images/<?php echo $profile_pic; ?>" alt="Profile">
                            <?php echo $username; ?>
                        </div>
                        <div class="user-dropdown-content">
                            <a href="account.php"><i class="fas fa-user"></i> My Account</a>
                            <a href="my_orders.php"><i class="fas fa-shopping-bag"></i> My Orders</a>
                            <a href="change_password.php"><i class="fas fa-key"></i> Change Password</a>
                            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        </div>
                    </li>
                </ul>
            </nav>
        </div>
    </header>
    
    <div class="container">
        <h2>My Orders</h2>
        
        <?php if (!empty($notifications)): ?>
            <div class="notifications-container">
                <h3>Notifications <span class="notification-badge"><?php echo count($notifications); ?></span></h3>
                <?php foreach ($notifications as $notification): ?>
                    <div class="notification">
                        <div class="notification-title"><?php echo htmlspecialchars($notification['title']); ?></div>
                        <div class="notification-message"><?php echo htmlspecialchars($notification['message']); ?></div>
                                                <div class="notification-time"><?php echo date('F j, Y, g:i a', strtotime($notification['created_at'])); ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
        
        <?php if (empty($orders)): ?>
            <div class="empty-state">
                <i class="fas fa-shopping-bag"></i>
                <h3>No Orders Yet</h3>
                <p>You haven't placed any orders yet. Start shopping to see your orders here!</p>
                <a href="products.php" class="btn">Shop Now</a>
            </div>
        <?php else: ?>
            <div class="orders-container">
                <?php foreach ($orders as $order): ?>
                    <div class="order-card">
                        <div class="order-header">
                            <div class="order-id">Order #<?php echo $order['id']; ?></div>
                            <div class="order-date"><?php echo date('F j, Y', strtotime($order['order_date'])); ?></div>
                        </div>
                        <div class="order-body">
                            <div class="order-details">
                                <div class="order-detail">
                                    <div class="order-detail-label">Status</div>
                                    <div class="order-detail-value">
                                        <span class="order-status status-<?php echo strtolower($order['status']); ?>">
                                            <?php echo $order['status']; ?>
                                        </span>
                                    </div>
                                </div>
                                <div class="order-detail">
                                    <div class="order-detail-label">Total Amount</div>
                                    <div class="order-detail-value">₱<?php echo number_format($order['total_amount'], 2); ?></div>
                                </div>
                                
                                <div class="order-detail">
                                    <div class="order-detail-label">Fulfillment Method</div>
                                    <div class="order-detail-value"><?php echo ucfirst($order['fulfillment_option']); ?></div>
                                </div>
                                <div class="order-detail">
                                    <div class="order-detail-label">Payment Method</div>
                                    <div class="order-detail-value"><?php echo $order['payment_method']; ?></div>
                                </div>
                            </div>
                            
                            <!-- Display order items/products -->
                            <?php if (!empty($order['items'])): ?>
                            <div class="order-products">
                                <div class="order-products-title">Products</div>
                                <ul class="product-list">
                                    <?php foreach ($order['items'] as $item): ?>
                                    <li class="product-item">
                                        <img src="images/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" class="product-image">
                                        <span class="product-name"><?php echo htmlspecialchars($item['name']); ?></span>
                                        <span class="product-quantity">x<?php echo $item['quantity']; ?></span>
                                    </li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                            <?php endif; ?>
                            
                            <div class="order-actions">
                                <a href="order_details.php?id=<?php echo $order['id']; ?>" class="btn">View Details</a>
                                
                                <?php if (strtolower($order['status']) == 'pending' || strtolower($order['status']) == 'processing'): ?>
                                    <a href="edit_order.php?id=<?php echo $order['id']; ?>" class="btn btn-edit">Edit Order</a>
                                    <a href="cancel_order.php?id=<?php echo $order['id']; ?>" class="btn btn-cancel" onclick="return confirm('Are you sure you want to cancel this order?');">Cancel Order</a>
                                <?php endif; ?>
                                
                                <?php if (strtolower($order['status']) == 'cancelled' || strtolower($order['status']) == 'completed' || strtolower($order['status']) == 'delivered'): ?>
                                    <a href="delete_order.php?id=<?php echo $order['id']; ?>" class="btn btn-delete" onclick="return confirm('Are you sure you want to delete this order? This action cannot be undone.');">
                                        <i class="fas fa-trash"></i>
                                     </a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </div>
    
    <footer>
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> BLASTICAKES & CRAFTS. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
