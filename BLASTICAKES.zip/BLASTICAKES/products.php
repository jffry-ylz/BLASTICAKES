<?php
// Start session
session_start();

// Check if user is logged in
$logged_in = isset($_SESSION['user_id']);
$username = $logged_in ? $_SESSION['username'] : '';
$is_admin = $logged_in && isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;

// If user is admin, redirect to admin.php
if ($is_admin) {
    header("Location: admin.php");
    exit();
}

// Include database connection
require_once 'includes/db.php';

// Get user data if logged in
$user = [];
if ($logged_in) {
    $user_id = $_SESSION['user_id'];
    $user_query = "SELECT * FROM users WHERE id = ?";
    $stmt = mysqli_prepare($conn, $user_query);
    mysqli_stmt_bind_param($stmt, "i", $user_id);
    mysqli_stmt_execute($stmt);
    $user_result = mysqli_stmt_get_result($stmt);
    if ($user_row = mysqli_fetch_assoc($user_result)) {
        $user = $user_row;
    }
}

// Get category filter from URL
$category = isset($_GET['category']) ? $_GET['category'] : '';

// Prepare query based on category filter
if (!empty($category)) {
    $sql = "SELECT * FROM products WHERE category = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $category);
} else {
    $sql = "SELECT * FROM products";
    $stmt = mysqli_prepare($conn, $sql);
}
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products - BLASTICAKES & CRAFTS</title>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
        }
        
        header {
            background-color: #ff6b6b;
            color: white;
            padding: 10px 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
        }
        
        header h1 {
            margin: 0;
            font-size: 28px;
        }
        
        nav ul {
            list-style: none;
            display: flex;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            margin-left: 20px;
        }
        
        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        
        nav ul li a:hover {
            background-color: rgba(255,255,255,0.2);
        }
        
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 20px 0;
            margin-top: 50px;
        }
        
        /* User dropdown menu */
        .user-dropdown {
            position: relative;
            display: inline-block;
        }
        
        .user-dropdown-btn {
            display: flex;
            align-items: center;
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .user-dropdown-btn:hover {
            background-color: rgba(255,255,255,0.2);
        }
        
        .user-dropdown-btn img {
            width: 25px;
            height: 25px;
            border-radius: 50%;
            margin-right: 8px;
            object-fit: cover;
        }
        
        .user-dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 180px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .user-dropdown-content a {
            color: #333;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }
        
        .user-dropdown-content a:hover {
            background-color: #f1f1f1;
        }
        
        .user-dropdown:hover .user-dropdown-content {
            display: block;
        }
        
        /* Page specific styles */
        .page-title {
            color: #ff6b6b;
            margin-bottom: 30px;
            text-align: center;
            font-size: 2em;
        }
        
        .filters {
            display: flex;
            justify-content: center;
            margin-bottom: 30px;
            background-color: white;
            padding: 15px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        .filters a {
            margin: 0 15px;
            padding: 8px 20px;
            color: #555;
            text-decoration: none;
            border-radius: 20px;
            transition: all 0.3s;
        }
        
        .filters a:hover {
            background-color: #ffeded;
            color: #ff6b6b;
        }
        
        .filters a.active {
            background-color: #ff6b6b;
            color: white;
            font-weight: bold;
        }
        
        .products {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
            gap: 30px;
            margin-top: 30px;
        }
        
        .product {
            background-color: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            transition: transform 0.3s, box-shadow 0.3s;
        }
        
        .product:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0,0,0,0.2);
        }
        
        .product img {
            width: 100%;
            height: 200px;
            object-fit: cover;
            transition: transform 0.5s;
        }
        
        .product:hover img {
            transform: scale(1.05);
        }
        
        .product h3 {
            padding: 15px 15px 5px;
            margin: 0;
            color: #333;
            font-size: 1.2em;
        }
        
        .product p {
            padding: 0 15px;
            color: #666;
            font-size: 0.9em;
            height: 60px;
            overflow: hidden;
        }
        
        .price {
            padding: 5px 15px;
            font-size: 1.3em;
            color: #ff6b6b;
            font-weight: bold;
        }
        
        .delivery-date {
            padding: 5px 15px;
            font-size: 0.8em;
            color: #888;
            border-top: 1px solid #eee;
            margin-top: 10px;
        }
        
        .product-info {
            padding: 5px 15px;
            font-size: 0.8em;
            color: #666;
            border-top: 1px solid #eee;
        }
        
        .stock {
            color: #28a745;
            font-weight: bold;
        }
        
        .low-stock {
            color: #ffc107;
            font-weight: bold;
        }
        
        .out-of-stock {
            color: #dc3545;
            font-weight: bold;
        }
        
        .lead-time {
            color: #17a2b8;
            font-weight: bold;
        }
        
        .btn {
            display: block;
            background-color: #ff6b6b;
            color: white;
            text-align: center;
            padding: 12px;
            text-decoration: none;
            font-weight: bold;
            margin: 15px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        
        .btn:hover {
            background-color: #ff5252;
        }
        
        .empty {
            grid-column: 1 / -1;
            text-align: center;
            padding: 50px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        }
        
        .empty h3 {
            color: #666;
            margin-bottom: 10px;
        }
        
        .empty p {
            color: #999;
        }
        
        /* Responsive design */
        @media (max-width: 768px) {
            .products {
                grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
            }
        }
        
        @media (max-width: 480px) {
            .products {
                grid-template-columns: 1fr;
            }
            
            .filters {
                flex-direction: column;
                align-items: center;
            }
            
            .filters a {
                margin: 5px 0;
                width: 100%;
                text-align: center;
            }
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>BLASTICAKES & CRAFTS</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="products.php">Products</a></li>
                    <?php if ($logged_in): ?>
                        <li><a href="my_orders.php">My Orders</a></li>
                        <li><a href="cart.php">Cart</a></li>
                        <li class="user-dropdown">
                            <div class="user-dropdown-btn">
                                <?php 
                                // Get user profile picture
                                $profile_pic = !empty($user['profile_picture']) ? $user['profile_picture'] : 'default_profile.png';
                                ?>
                                <img src="profile_images/<?php echo $profile_pic; ?>" alt="Profile">
                            </div>
                            <div class="user-dropdown-content">
                                <a href="account.php"><i class="fas fa-user"></i> My Account</a>
                                <a href="my_orders.php"><i class="fas fa-shopping-bag"></i> My Orders</a>
                                <a href="change_password.php"><i class="fas fa-key"></i> Change Password</a>
                                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                            </div>
                        </li>
                    <?php else: ?>
                        <li><a href="login.php">Login</a></li>
                        <li><a href="signup.php">Sign Up</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>
    
    <div class="container">
        <h1 class="page-title">Our Products</h1>
        
        <div class="filters">
            <a href="products.php" <?php echo $category === '' ? 'class="active"' : ''; ?>>All Products</a>
            <a href="products.php?category=cake" <?php echo $category === 'cake' ? 'class="active"' : ''; ?>>Cakes</a>
            <a href="products.php?category=craft" <?php echo $category === 'craft' ? 'class="active"' : ''; ?>>Crafts</a>
        </div>
        
        <div class="products">
            <?php if ($result && mysqli_num_rows($result) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <div class="product">
                        <img src="images/<?php echo htmlspecialchars($row['image']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>">
                        <h3><?php echo htmlspecialchars($row['name']); ?></h3>
                        <p><?php echo htmlspecialchars(strlen($row['description']) > 100 ? substr($row['description'], 0, 100) . "..." : $row['description']); ?></p>
                        <div class="price">₱<?php echo number_format($row['price'], 2); ?></div>
                        
                        <!-- Stock Quantity Display -->
                        <div class="product-info">
                            <?php if (isset($row['stock'])): ?>
                                <div>
                                    Stock Quantity: 
                                    <?php if ($row['stock'] > 10): ?>
                                        <span class="stock"><?php echo $row['stock']; ?> available</span>
                                    <?php elseif ($row['stock'] > 0): ?>
                                        <span class="low-stock">Only <?php echo $row['stock']; ?> left!</span>
                                    <?php else: ?>
                                        <span class="out-of-stock">Out of stock</span>
                                    <?php endif; ?>
                                </div>
                            <?php endif; ?>
                            
                            <!-- Lead Time Display -->
                            <?php if (isset($row['lead_time'])): ?>
                                <div>
                                    <span class="lead-time">Order at least <?php echo $row['lead_time']; ?> days before desired date</span>
                                </div>
                            <?php endif; ?>
                        </div>
                        
                        <div class="delivery-date">
                            Order now, get it by: <?php echo date('F j, Y', strtotime($row['delivery_datetime'])); ?>
                        </div>
                        
                        <?php if ($logged_in): ?>
                            <a href="add_to_cart.php
                            ?id=<?php echo (int)$row['id']; ?>" class="btn">Add to Cart</a>
                        <?php else: ?>
                            <a href="login.php" class="btn">Login to Buy</a>
                        <?php endif; ?>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="empty">
                    <h3>No products found</h3>
                    <p>Please check back later for new products.</p>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <footer>
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> BLASTICAKES & CRAFTS. All rights reserved.</p>
        </div>
    </footer>
</body>
</html>
