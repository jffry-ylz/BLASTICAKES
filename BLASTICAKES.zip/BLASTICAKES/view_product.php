<?php
// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Include database connection
require_once 'includes/db.php';

// Get user info
$username = $_SESSION['username'];
$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;

// Check if product ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: " . ($is_admin ? "admin.php" : "products.php"));
    exit;
}

$product_id = $_GET['id'];

// Get product details
$sql = "SELECT * FROM products WHERE id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "i", $product_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if (mysqli_num_rows($result) == 0) {
    // Product not found
    header("Location: " . ($is_admin ? "admin.php" : "products.php"));
    exit;
}

$product = mysqli_fetch_assoc($result);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $product['name']; ?> - BLASTICAKES & CRAFTS</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        header {
            background-color: #ff6b6b;
            color: white;
            padding: 1rem;
        }
        .container {
            width: 90%;
            margin: 0 auto;
            overflow: hidden;
        }
        nav {
            float: right;
        }
        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
        }
        nav li {
            display: inline;
            margin-left: 15px;
        }
        nav a {
            color: white;
            text-decoration: none;
        }
        .product-container {
            background: white;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-top: 20px;
            display: flex;
            flex-wrap: wrap;
        }
        .product-image {
            flex: 1;
            min-width: 300px;
            text-align: center;
        }
        .product-image img {
            max-width: 100%;
            max-height: 400px;
            border-radius: 5px;
        }
        .product-details {
            flex: 1;
            min-width: 300px;
            padding: 0 20px;
        }
        .product-title {
            font-size: 24px;
            margin-bottom: 10px;
        }
        .product-category {
            color: #666;
            margin-bottom: 15px;
            font-style: italic;
        }
        .product-price {
            font-size: 22px;
            color: #ff6b6b;
            margin-bottom: 15px;
            font-weight: bold;
        }
        .product-stock {
            margin-bottom: 15px;
        }
        .product-description {
            margin-bottom: 20px;
            line-height: 1.8;
        }
        .btn {
            display: inline-block;
            background-color: #ff6b6b;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
        .btn:hover {
            background-color: #ff5252;
        }
        .btn-secondary {
            background-color: #6c757d;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .actions {
            margin-top: 20px;
            display: flex;
            gap: 10px;
        }
        .stock-status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 4px;
            font-size: 14px;
            font-weight: bold;
        }
        .in-stock {
            background-color: #d4edda;
            color: #155724;
        }
        .low-stock {
            background-color: #fff3cd;
            color: #856404;
        }
        .out-of-stock {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>BLASTICAKES & CRAFTS</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="products.php">Products</a></li>
                    <?php if (!$is_admin): ?>
                        <li><a href="cart.php">Cart</a></li>
                    <?php endif; ?>
                    <?php if ($is_admin): ?>
                        <li><a href="admin.php">Admin Panel</a></li>
                    <?php endif; ?>
                    <li><a href="logout.php">Logout (<?php echo $username; ?>)</a></li>
                </ul>
            </nav>
        </div>
    </header>
    
    <div class="container">
        <div class="product-container">
            <div class="product-image">
                <img src="images/<?php echo $product['image']; ?>" alt="<?php echo $product['name']; ?>">
            </div>
            <div class="product-details">
                <h2 class="product-title"><?php echo $product['name']; ?></h2>
                <div class="product-category">Category: <?php echo ucfirst($product['category']); ?></div>
                <div class="product-price">₱<?php echo number_format($product['price'], 2); ?></div>
                <div class="product-stock">
                    <?php if ($product['stock'] > 10): ?>
                        <span class="stock-status in-stock">In Stock (<?php echo $product['stock']; ?> available)</span>
                    <?php elseif ($product['stock'] > 0): ?>
                        <span class="stock-status low-stock">Low Stock (Only <?php echo $product['stock']; ?> left)</span>
                    <?php else: ?>
                        <span class="stock-status out-of-stock">Out of Stock</span>
                    <?php endif; ?>
                </div>
                <div class="product-description">
                    <h3>Description:</h3>
                    <p><?php echo nl2br($product['description']); ?></p>
                </div>
                
                <div class="actions">
                    <?php if ($is_admin): ?>
                        <a href="edit_product.php?id=<?php echo $product['id']; ?>" class="btn">Edit Product</a>
                        <a href="admin.php" class="btn btn-secondary">Back to Admin Panel</a>
                    <?php else: ?>
                        <?php if ($product['stock'] > 0): ?>
                            <form action="add_to_cart.php" method="post">
                                <input type="hidden" name="product_id" value="<?php echo $product['id']; ?>">
                                <input type="hidden" name="quantity" value="1">
                                <button type="submit" class="btn">Add to Cart</button>
                            </form>
                        <?php endif; ?>
                        <a href="products.php" class="btn btn-secondary">Back to Products</a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
