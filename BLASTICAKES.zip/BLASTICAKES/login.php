<?php
session_start();

require_once 'includes/db.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_POST['username']) || empty($_POST['password'])) {
        $error = "Username and password are required";
    } else {
        $username = trim($_POST['username']);
        $password = $_POST['password'];

        if (!$conn) {
            $error = "Database connection failed: " . mysqli_connect_error();
        } else {
            $sql = "SELECT * FROM users WHERE username = ? LIMIT 1";
            $stmt = mysqli_prepare($conn, $sql);

            if ($stmt) {
                mysqli_stmt_bind_param($stmt, "s", $username);
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);

                if ($result && mysqli_num_rows($result) === 1) {
                    $user = mysqli_fetch_assoc($result);

                    // Plain text password check
                    if ($password === $user['PASSWORD']) {
                        $_SESSION['user_id'] = $user['id'];
                        $_SESSION['username'] = $user['username'];
                        $_SESSION['is_admin'] = $user['is_admin'];

                        header("Location: " . ($user['is_admin'] == 1 ? "admin.php" : "index.php"));
                        exit();
                    } else {
                        $error = "Invalid username or password.";
                    }
                } else {
                    $error = "Invalid username or password.";
                }
                mysqli_stmt_close($stmt);
            } else {
                $error = "SQL Error: " . mysqli_error($conn);
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Login - Cake Shop</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
    <style>
        body { font-family: Arial, sans-serif; background-color: #f9f9f9; padding: 20px; }
        .container { max-width: 400px; margin: 50px auto; background: white; padding: 30px; border-radius: 5px; box-shadow: 0 0 10px rgba(0,0,0,0.1); }
        h1 { text-align: center; color: #ff6b6b; }
        .form-group { margin-bottom: 20px; }
        label { font-weight: bold; display: block; margin-bottom: 8px; }
        input[type="text"], input[type="password"] { width: 100%; padding: 12px; border: 1px solid #ddd; border-radius: 4px; font-size: 16px; }
        .btn { background-color: #ff6b6b; color: white; padding: 12px; border: none; border-radius: 4px; width: 100%; font-size: 16px; cursor: pointer; }
        .btn:hover { background-color: #ff5252; }
        .error { background-color: #f8d7da; color: #721c24; padding: 12px; border-radius: 4px; border: 1px solid #f5c6cb; margin-bottom: 20px; }
        .signup-link { text-align: center; margin-top: 20px; border-top: 1px solid #eee; padding-top: 15px; }
        .signup-link a { color: #ff6b6b; text-decoration: none; }
        .signup-link a:hover { text-decoration: underline; }
        .password-field { position: relative; }
        .toggle-password { position: absolute; right: 10px; top: 12px; cursor: pointer; color: #666; }
    </style>
</head>
<body>
    <div class="container">
        <h1>Login</h1>
        <?php if (!empty($error)): ?>
            <div class="error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>

        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
            <div class="form-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" value="<?php echo isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''; ?>" required />
            </div>
            <div class="form-group password-field">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required />
                <span class="toggle-password" onclick="togglePasswordVisibility()">
                    <i class="fas fa-eye"></i>
                </span>
            </div>
            <button type="submit" class="btn">Login</button>
        </form>

        <div class="signup-link">
            Don't have an account? <a href="signup.php">Sign up here</a>
        </div>
    </div>

    <script>
        function togglePasswordVisibility() {
            const pwField = document.getElementById("password");
            const icon = document.querySelector(".toggle-password i");
            if (pwField.type === "password") {
                pwField.type = "text";
                icon.classList.replace("fa-eye", "fa-eye-slash");
            } else {
                pwField.type = "password";
                icon.classList.replace("fa-eye-slash", "fa-eye");
            }
        }
    </script>
</body>
</html>
