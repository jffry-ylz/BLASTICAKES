<?php
// Start session
session_start();

// Include database connection
require_once 'includes/db.php';

// Initialize variables
$error = "";
$success = "";
$form_submitted = false;

// If user is already logged in, redirect to home page
if (isset($_SESSION['user_id'])) {
    header("Location: index.php");
    exit;
}

// Process registration form when submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get and sanitize form data
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $email = mysqli_real_escape_string($conn, $_POST['email']);
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];
    
    // Check if terms are accepted
    $terms_accepted = isset($_POST['terms']) ? 1 : 0;
    
    // Validate input
    if (empty($username) || empty($email) || empty($password) || empty($confirm_password)) {
        $error = "All fields are required";
    } elseif ($password !== $confirm_password) {
        $error = "Passwords do not match";
    } elseif (!preg_match('/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/', $password)) {
        $error = "Password must be at least 8 characters, include an uppercase letter, a number, and a special character";
    } elseif (!$terms_accepted) {
        $error = "You must accept the Terms and Conditions to register";
    } else {
        // Check if username already exists
        $sql = "SELECT id FROM users WHERE username = '$username'";
        $result = mysqli_query($conn, $sql);
        
        if (mysqli_num_rows($result) > 0) {
            $error = "Username already exists";
        } else {
            // Check if email already exists
            $sql = "SELECT id FROM users WHERE email = '$email'";
            $result = mysqli_query($conn, $sql);
            
            if (mysqli_num_rows($result) > 0) {
                $error = "Email already exists";
            } else {
                // STORE PLAIN TEXT PASSWORD (FOR TESTING ONLY - NOT SECURE)
                $sql = "INSERT INTO users (username, email, password) 
                        VALUES ('$username', '$email', '$password')";
                
                if (mysqli_query($conn, $sql)) {
                    $success = "Registration successful! You can now login.";
                    $form_submitted = true;
                    // Clear form data on successful submission
                    $username = "";
                    $email = "";
                    $password = "";
                    $confirm_password = "";
                } else {
                    $error = "Error: " . mysqli_error($conn);
                }
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up - Cake Shop</title>
    <!-- Font Awesome for eye icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 20px;
            background-color: #f9f9f9;
        }
        .container {
            max-width: 500px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        h1 {
            text-align: center;
            color: #ff6b6b;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"],
        input[type="tel"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .btn {
            display: inline-block;
            background-color: #ff6b6b;
            color: white;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 100%;
        }
        .btn:hover {
            background-color: #ff5252;
        }
        .error {
            color: #721c24;
            background-color: #f8d7da;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        .success {
            color: #155724;
            background-color: #d4edda;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        .login-link {
            text-align: center;
            margin-top: 15px;
        }
        .password-requirements {
            font-size: 12px;
            color: #666;
            margin-top: 5px;
            display: none;
        }
        .password-requirement {
            margin-bottom: 3px;
        }
        .terms-container {
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            max-height: 100px;
            overflow-y: auto;
            background-color: #f9f9f9;
            font-size: 12px;
        }
        .checkbox-group {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
        }
        .checkbox-group input {
            margin-right: 10px;
        }
        .form-section {
            border-bottom: 1px solid #eee;
            padding-bottom: 15px;
            margin-bottom: 15px;
        }
        .form-section h3 {
            color: #ff6b6b;
            margin-top: 0;
        }
        .password-field {
            position: relative;
        }
        .toggle-password {
            position: absolute;
            right: 10px;
            top: 10px;
            cursor: pointer;
            color: #666;
            font-size: 16px;
        }
        .valid {
            color: #28a745;
        }
        .invalid {
            color: #dc3545;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Sign Up</h1>
        
        <?php if (!empty($error)): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>
        
        <?php if (!empty($success)): ?>
            <div class="success"><?php echo $success; ?></div>
        <?php endif; ?>
        
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" id="signup-form">
            <div class="form-section">
                <h3>Account Information</h3>
                <div class="form-group">
                    <label for="username">Username*</label>
                    <input type="text" id="username" name="username" value="<?php echo $form_submitted ? '' : (isset($_POST['username']) ? htmlspecialchars($_POST['username']) : ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="email">Email*</label>
                    <input type="email" id="email" name="email" value="<?php echo $form_submitted ? '' : (isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''); ?>">
                </div>
                
                <div class="form-group">
                    <label for="password">Password*</label>
                    <div class="password-field">
                        <input type="password" id="password" name="password" onkeyup="checkPassword(this.value)" onfocus="showPasswordRequirements()" onblur="hidePasswordRequirements()">
                        <span class="toggle-password" onclick="togglePasswordVisibility('password')">
                            <i class="fas fa-eye"></i>
                        </span>
                    </div>
                    <div id="password-requirements" class="password-requirements">
                        <div id="length" class="password-requirement">
                            <span class="requirement-icon">✓</span> Minimum length: At least 8 characters
                        </div>
                        <div id="uppercase" class="password-requirement">
                            <span class="requirement-icon">✓</span> At least one uppercase letter
                        </div>
                        <div id="lowercase" class="password-requirement">
                            <span class="requirement-icon">✓</span> At least one lowercase letter
                        </div>
                        <div id="number" class="password-requirement">
                            <span class="requirement-icon">✓</span> At least one number
                        </div>
                        <div id="special" class="password-requirement">
                            <span class="requirement-icon">✓</span> At least one special character
                        </div>
                    </div>
                </div>
                
                <div class="form-group">
                    <label for="confirm_password">Confirm Password*</label>
                    <div class="password-field">
                        <input type="password" id="confirm_password" name="confirm_password">
                        <span class="toggle-password" onclick="togglePasswordVisibility('confirm_password')">
                            <i class="fas fa-eye"></i>
                        </span>
                    </div>
                </div>
            </div>
            
            <div class="terms-container">
                <strong>Terms and Conditions</strong>
                <p>By creating an account on BLASTICAKES & CRAFTS, you agree to the following terms:</p>
                <ol>
                    <li>All personal information provided is accurate and will be kept confidential.</li>
                    <li>You are responsible for maintaining the security of your account credentials.</li>
                    <li>BLASTICAKES & CRAFTS reserves the right to modify or cancel orders in certain circumstances.</li>
                    <li>Delivery times are estimates and may vary based on location and availability.</li>
                    <li>Payment information will be processed securely through our payment partners.</li>
                </ol>
            </div>
            
            <div class="checkbox-group">
                <input type="checkbox" id="terms" name="terms" <?php echo $form_submitted ? '' : (isset($_POST['terms']) ? 'checked' : ''); ?>>
                <label for="terms">I agree to the Terms and Conditions*</label>
            </div>
            
            <button type="submit" class="btn">Sign Up</button>
        </form>
        
        <div class="login-link">
            Already have an account? <a href="login.php">Login here</a>
        </div>
    </div>

    <script>
        function togglePasswordVisibility(fieldId) {
            const passwordField = document.getElementById(fieldId);
            const toggleButton = passwordField.nextElementSibling.querySelector('i');
            
            if (passwordField.type === "password") {
                passwordField.type = "text";
                toggleButton.classList.remove('fa-eye');
                toggleButton.classList.add('fa-eye-slash');
            } else {
                passwordField.type = "password";
                toggleButton.classList.remove('fa-eye-slash');
                toggleButton.classList.add('fa-eye');
            }
        }
        
        function showPasswordRequirements() {
            document.getElementById('password-requirements').style.display = 'block';
        }
        
        function hidePasswordRequirements() {
            // Only hide if not focused
            if (document.activeElement !== document.getElementById('password')) {
                document.getElementById('password-requirements').style.display = 'none';
            }
        }
        
        function checkPassword(password) {
            // Check length
            const lengthRequirement = document.getElementById('length');
            if (password.length >= 8) {
                lengthRequirement.classList.add('valid');
                lengthRequirement.classList.remove('invalid');
            } else {
                lengthRequirement.classList.add('invalid');
                lengthRequirement.classList.remove('valid');
            }
            
            // Check uppercase
            const uppercaseRequirement = document.getElementById('uppercase');
            if (/[A-Z]/.test(password)) {
                uppercaseRequirement.classList.add('valid');
                uppercaseRequirement.classList.remove('invalid');
            } else {
                uppercaseRequirement.classList.add('invalid');
                uppercaseRequirement.classList.remove('valid');
            }
            
            // Check lowercase
            const lowercaseRequirement = document.getElementById('lowercase');
            if (/[a-z]/.test(password)) {
                lowercaseRequirement.classList.add('valid');
                lowercaseRequirement.classList.remove('invalid');
            } else {
                lowercaseRequirement.classList.add('invalid');
                lowercaseRequirement.classList.remove('valid');
            }
            
            // Check number
            const numberRequirement = document.getElementById('number');
            if (/[0-9]/.test(password)) {
                numberRequirement.classList.add('valid');
                numberRequirement.classList.remove('invalid');
            } else {
                numberRequirement.classList.add('invalid');
                numberRequirement.classList.remove('valid');
            }
            
            // Check special character
            const specialRequirement = document.getElementById('special');
            if (/[^A-Za-z0-9]/.test(password)) {
                specialRequirement.classList.add('valid');
                specialRequirement.classList.remove('invalid');
            } else {
                specialRequirement.classList.add('invalid');
                specialRequirement.classList.remove('valid');
            }
        }

        // Clear form if registration was successful
        <?php if ($success): ?>
        document.addEventListener('DOMContentLoaded', function() {
            document.getElementById('signup-form').reset();
        });
        <?php endif; ?>
    </script>
</body>
</html>
