<?php
// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Include database connection
require_once 'includes/db.php';

$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$success_message = '';
$error_message = '';

// Get user information
$user_query = "SELECT * FROM users WHERE id = ?";
$stmt = mysqli_prepare($conn, $user_query);
mysqli_stmt_bind_param($stmt, "i", $user_id);
mysqli_stmt_execute($stmt);
$user_result = mysqli_stmt_get_result($stmt);
$user = mysqli_fetch_assoc($user_result);

// Handle profile update
if (isset($_POST['update_profile'])) {
    $new_username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $full_name = trim($_POST['full_name']);
    $address = trim($_POST['address']);
    $phone = trim($_POST['phone']);
    
    // Validate username (not empty and unique)
    if (empty($new_username)) {
        $error_message = "Username cannot be empty";
    } else {
        // Check if username exists (if it's different from current username)
        if ($new_username !== $username) {
            $check_query = "SELECT id FROM users WHERE username = ? AND id != ?";
            $check_stmt = mysqli_prepare($conn, $check_query);
            mysqli_stmt_bind_param($check_stmt, "si", $new_username, $user_id);
            mysqli_stmt_execute($check_stmt);
            $check_result = mysqli_stmt_get_result($check_stmt);
            
            if (mysqli_num_rows($check_result) > 0) {
                $error_message = "Username already exists. Please choose another one.";
            }
            mysqli_stmt_close($check_stmt);
        }
    }
    
    // If no errors, update profile
    if (empty($error_message)) {
        // Handle profile picture upload
        $profile_picture = $user['profile_picture']; // Keep existing by default
        
        if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] == 0) {
            $allowed_types = ['image/jpeg', 'image/png', 'image/gif'];
            $max_size = 5 * 1024 * 1024; // 5MB
            
            if (!in_array($_FILES['profile_picture']['type'], $allowed_types)) {
                $error_message = "Only JPG, PNG and GIF images are allowed";
            } elseif ($_FILES['profile_picture']['size'] > $max_size) {
                $error_message = "Image size should be less than 5MB";
            } else {
                // Create profile_images directory if it doesn't exist
                if (!file_exists('profile_images')) {
                    mkdir('profile_images', 0777, true);
                }
                
                // Generate unique filename
                $file_extension = pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION);
                $new_filename = 'profile_' . $user_id . '_' . time() . '.' . $file_extension;
                $upload_path = 'profile_images/' . $new_filename;
                
                // Move uploaded file
                if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $upload_path)) {
                    // Delete old profile picture if it exists and is not the default
                    if (!empty($profile_picture) && $profile_picture != 'default_profile.png' && file_exists('profile_images/' . $profile_picture)) {
                        unlink('profile_images/' . $profile_picture);
                    }
                    
                    $profile_picture = $new_filename;
                } else {
                    $error_message = "Failed to upload image. Please try again.";
                }
            }
        }
        
        if (empty($error_message)) {
            // Update user profile
            $update_query = "UPDATE users SET username = ?, email = ?, full_name = ?, address = ?, phone = ?, profile_picture = ? WHERE id = ?";
            $update_stmt = mysqli_prepare($conn, $update_query);
            mysqli_stmt_bind_param($update_stmt, "ssssssi", $new_username, $email, $full_name, $address, $phone, $profile_picture, $user_id);
            
            if (mysqli_stmt_execute($update_stmt)) {
                // Update session username if changed
                if ($new_username !== $username) {
                    $_SESSION['username'] = $new_username;
                    $username = $new_username;
                }
                
                $success_message = "Profile updated successfully!";
                
                // Refresh user data
                mysqli_stmt_execute($stmt);
                $user_result = mysqli_stmt_get_result($stmt);
                $user = mysqli_fetch_assoc($user_result);
            } else {
                $error_message = "Error updating profile: " . mysqli_error($conn);
            }
            
            mysqli_stmt_close($update_stmt);
        }
    }
}

// Handle account deletion
if (isset($_POST['delete_account']) && isset($_POST['confirm_delete'])) {
    // First check if there are any pending orders
    $order_check_query = "SELECT id FROM orders WHERE user_id = ? AND status != 'Completed' AND status != 'Cancelled'";
    $order_check_stmt = mysqli_prepare($conn, $order_check_query);
    mysqli_stmt_bind_param($order_check_stmt, "i", $user_id);
    mysqli_stmt_execute($order_check_stmt);
    $order_check_result = mysqli_stmt_get_result($order_check_stmt);
    
    if (mysqli_num_rows($order_check_result) > 0) {
        $error_message = "Cannot delete account while you have pending orders. Please contact support for assistance.";
    } else {
        // Delete user's profile picture if it exists and is not the default
        if (!empty($user['profile_picture']) && $user['profile_picture'] != 'default_profile.png' && file_exists('profile_images/' . $user['profile_picture'])) {
            unlink('profile_images/' . $user['profile_picture']);
        }
        
        // Delete user account
        $delete_query = "DELETE FROM users WHERE id = ?";
        $delete_stmt = mysqli_prepare($conn, $delete_query);
        mysqli_stmt_bind_param($delete_stmt, "i", $user_id);
        
        if (mysqli_stmt_execute($delete_stmt)) {
            // Destroy session and redirect to home page
            session_destroy();
            header("Location: index.php?account_deleted=1");
            exit();
        } else {
            $error_message = "Error deleting account: " . mysqli_error($conn);
        }
        
        mysqli_stmt_close($delete_stmt);
    }
    
    mysqli_stmt_close($order_check_stmt);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Account - BLASTICAKES & CRAFTS</title>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
        }
        
        header {
            background-color: #ff6b6b;
            color: white;
            padding: 10px 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
        }
        
        header h1 {
            margin: 0;
            font-size: 28px;
        }
        
        nav ul {
            list-style: none;
            display: flex;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            margin-left: 20px;
        }
        
        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        
        nav ul li a:hover {
            background-color: rgba(255,255,255,0.2);
        }
        
        .page-title {
            text-align: center;
            margin: 30px 0;
            color: #333;
        }
        
        .account-container {
            display: flex;
            flex-wrap: wrap;
            gap: 30px;
            margin-bottom: 50px;
        }
        
        .account-sidebar {
            flex: 1;
            min-width: 250px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 20px;
            text-align: center;
        }
        
        .account-content {
            flex: 3;
            min-width: 300px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 30px;
        }
        
        .profile-picture {
            width: 150px;
            height: 150px;
            border-radius: 50%;
            object-fit: cover;
            margin: 0 auto 20px;
            border: 5px solid #f0f0f0;
        }
        
        .user-name {
            font-size: 1.5em;
            margin-bottom: 5px;
            color: #333;
        }
        
        .user-email {
            color: #777;
            margin-bottom: 20px;
        }
        
        
        .account-menu {
            list-style: none;
            padding: 0;
            margin: 20px 0;
        }
        
        .account-menu li {
            margin-bottom: 10px;
        }
        
        .account-menu a {
            display: block;
            padding: 10px;
            color: #333;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        
        .account-menu a:hover, .account-menu a.active {
            background-color: #ffeded;
            color: #ff6b6b;
        }
        
        .account-menu a i {
            margin-right: 10px;
            width: 20px;
            text-align: center;
        }
        
        .section-title {
            color: #333;
            margin-top: 0;
            margin-bottom: 25px;
            padding-bottom: 10px;
            border-bottom: 2px solid #f0f0f0;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: bold;
        }
        
        .form-control {
            width: 100%;
            padding: 10px 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            transition: border-color 0.3s;
        }
        
        .form-control:focus {
            border-color: #ff6b6b;
            outline: none;
        }
        
        .btn {
            display: inline-block;
            background-color: #ff6b6b;
            color: white;
            padding: 12px 25px;
            text-decoration: none;
            border-radius: 4px;
            font-weight: bold;
            transition: background-color 0.3s;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
        
        .btn:hover {
            background-color: #ff5252;
        }
        
        .btn-secondary {
            background-color: #6c757d;
        }
        
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        
        .btn-danger {
            background-color: #dc3545;
        }
        
        .btn-danger:hover {
            background-color: #c82333;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .delete-account-section {
            margin-top: 50px;
            padding-top: 30px;
            border-top: 2px solid #f0f0f0;
        }
        
        .delete-account-section h3 {
            color: #dc3545;
        }
        
        .delete-account-section p {
            color: #666;
            margin-bottom: 20px;
        }
        
        .delete-confirmation {
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
            display: none;
        }
        
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 20px 0;
            margin-top: 50px;
        }
        
        /* User dropdown menu */
        .user-dropdown {
            position: relative;
            display: inline-block;
        }
        
        .user-dropdown-btn {
            display: flex;
            align-items: center;
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .user-dropdown-btn:hover {
            background-color: rgba(255,255,255,0.2);
        }
        
        .user-dropdown-btn img {
            width: 25px;
            height: 25px;
            border-radius: 50%;
            margin-right: 8px;
            object-fit: cover;
        }
        
                .user-dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 180px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .user-dropdown-content a {
            color: #333;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }
        
        .user-dropdown-content a:hover {
            background-color: #f1f1f1;
        }
        
        .user-dropdown:hover .user-dropdown-content {
            display: block;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>BLASTICAKES & CRAFTS</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="products.php">Products</a></li>
                    <li><a href="my_orders.php">My Orders</a></li>
                    <li><a href="cart.php">Cart</a></li>
                    <li class="user-dropdown">
                        <div class="user-dropdown-btn">
                            <?php 
                            // Get user profile picture
                            $profile_pic = !empty($user['profile_picture']) ? $user['profile_picture'] : 'default_profile.png';
                            ?>
                            <img src="profile_images/<?php echo $profile_pic; ?>" alt="Profile">
                            <?php echo $username; ?>
                        </div>
                        <div class="user-dropdown-content">
                            <a href="account.php"><i class="fas fa-user"></i> My Account</a>
                            <a href="my_orders.php"><i class="fas fa-shopping-bag"></i> My Orders</a>
                            <a href="change_password.php"><i class="fas fa-key"></i> Change Password</a>
                            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        </div>
                    </li>
                </ul>
            </nav>
        </div>
    </header>
    
    <div class="container">
        <h1 class="page-title">My Account</h1>
        
        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success">
                <?php echo $success_message; ?>
            </div>
        <?php endif; ?>
        
        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger">
                <?php echo $error_message; ?>
            </div>
        <?php endif; ?>
        
        <div class="account-container">
            <div class="account-sidebar">
                <?php 
                // Display profile picture
                $profile_pic = !empty($user['profile_picture']) ? $user['profile_picture'] : 'default_profile.png';
                ?>
                <img src="profile_images/<?php echo $profile_pic; ?>" alt="Profile Picture" class="profile-picture">
                <h2 class="user-name"><?php echo htmlspecialchars($user['username']); ?></h2>
                <p class="user-email"><?php echo htmlspecialchars($user['email']); ?></p>
                
                <ul class="account-menu">
                    <li><a href="account.php" class="active"><i class="fas fa-user"></i> Profile</a></li>
                    <li><a href="my_orders.php"><i class="fas fa-shopping-bag"></i> My Orders</a></li>
                    <li><a href="change_password.php"><i class="fas fa-key"></i> Change Password</a></li>
                    <li><a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a></li>
                </ul>
            </div>
            
            <div class="account-content">
                <h2 class="section-title">Edit Profile</h2>
                
                <form action="account.php" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="profile_picture">Profile Picture</label>
                        <input type="file" name="profile_picture" id="profile_picture" class="form-control">
                        <small>Leave empty to keep current picture. Max size: 5MB. Allowed formats: JPG, PNG, GIF.</small>
                    </div>
                    
                    <div class="form-group">
                        <label for="username">Username*</label>
                        <input type="text" name="username" id="username" class="form-control" value="<?php echo htmlspecialchars($user['username']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="email">Email*</label>
                        <input type="email" name="email" id="email" class="form-control" value="<?php echo htmlspecialchars($user['email']); ?>" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="full_name">Full Name</label>
                        <input type="text" name="full_name" id="full_name" class="form-control" value="<?php echo htmlspecialchars($user['full_name'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label for="address">Address</label>
                        <textarea name="address" id="address" class="form-control" rows="3"><?php echo htmlspecialchars($user['address'] ?? ''); ?></textarea>
                    </div>
                    
                    <div class="form-group">
                        <label for="phone">Phone Number</label>
                        <input type="text" name="phone" id="phone" class="form-control" value="<?php echo htmlspecialchars($user['phone'] ?? ''); ?>">
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" name="update_profile" class="btn">Update Profile</button>
                    </div>
                </form>
                
                <div class="delete-account-section">
                    <h3>Delete Account</h3>
                    <p>Warning: This action cannot be undone. All your data will be permanently deleted.</p>
                    
                    <button id="show-delete-confirmation" class="btn btn-danger">Delete My Account</button>
                    
                    <div id="delete-confirmation" class="delete-confirmation">
                        <p><strong>Are you sure you want to delete your account?</strong></p>
                        <p>This will permanently remove all your data including order history.</p>
                        
                        <form action="account.php" method="post">
                            <div class="form-group">
                                <label>
                                    <input type="checkbox" name="confirm_delete" required>
                                    I understand this action cannot be undone
                                </label>
                            </div>
                            
                            <div class="form-group">
                                <button type="submit" name="delete_account" class="btn btn-danger">Confirm Delete</button>
                                <button type="button" id="cancel-delete" class="btn btn-secondary">Cancel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <footer>
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> BLASTICAKES & CRAFTS. All rights reserved.</p>
        </div>
    </footer>
    
    <script>
        // Show/hide delete confirmation
        document.getElementById('show-delete-confirmation').addEventListener('click', function() {
            document.getElementById('delete-confirmation').style.display = 'block';
            this.style.display = 'none';
        });
        
        document.getElementById('cancel-delete').addEventListener('click', function() {
            document.getElementById('delete-confirmation').style.display = 'none';
            document.getElementById('show-delete-confirmation').style.display = 'inline-block';
        });
    </script>
</body>
</html>
