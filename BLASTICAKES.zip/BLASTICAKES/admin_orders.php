<?php
session_start();
require_once 'includes/db.php';
require_once 'includes/functions.php';

// Check if user is logged in and is an admin
if (!isset($_SESSION['user_id']) || !isset($_SESSION['is_admin']) || $_SESSION['is_admin'] != 1) {
    header("Location: login.php");
    exit();
}

$username = $_SESSION['username'];
$success_message = '';
$error_message = '';

// Handle order status update
if (isset($_POST['update_status']) && isset($_GET['order_id'])) {
    $order_id = $_GET['order_id'];
    $new_status = mysqli_real_escape_string($conn, $_POST['status']);
    
    // Update order status and notify customer
    if (update_order_status($order_id, $new_status)) {
        $success_message = "Order status updated successfully! Customer has been notified.";
    } else {
        $error_message = "Error updating order status: " . mysqli_error($conn);
    }
}

// Get order details if order_id is provided
if (isset($_GET['order_id'])) {
    $order_id = $_GET['order_id'];
    
    // Get order information
    $order_sql = "SELECT o.*, u.username, u.email FROM orders o 
                 JOIN users u ON o.user_id = u.id 
                 WHERE o.id = $order_id";
    $order_result = mysqli_query($conn, $order_sql);
    
    if ($order_result && mysqli_num_rows($order_result) > 0) {
        $order = mysqli_fetch_assoc($order_result);
        
        // Get order items
        $items_sql = "SELECT oi.*, p.name, p.image, p.price FROM order_items oi 
                     JOIN products p ON oi.product_id = p.id 
                     WHERE oi.order_id = $order_id";
        $items_result = mysqli_query($conn, $items_sql);
        $order_items = [];
        
        if ($items_result) {
            while ($item = mysqli_fetch_assoc($items_result)) {
                $order_items[] = $item;
            }
        }
    } else {
        $error_message = "Order not found.";
    }
}

// Get all orders for the orders list page
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;
$items_per_page = 10;
$offset = ($page - 1) * $items_per_page;

// Filter by status if provided
$status_filter = "";
if (isset($_GET['status']) && !empty($_GET['status'])) {
    $status = mysqli_real_escape_string($conn, $_GET['status']);
    $status_filter = "WHERE o.status = '$status'";
}

// Search by order ID or customer name
$search_filter = "";
if (isset($_GET['search']) && !empty($_GET['search'])) {
    $search = mysqli_real_escape_string($conn, $_GET['search']);
    if (empty($status_filter)) {
        $search_filter = "WHERE (o.id LIKE '%$search%' OR u.username LIKE '%$search%' OR u.email LIKE '%$search%')";
    } else {
        $search_filter = "AND (o.id LIKE '%$search%' OR u.username LIKE '%$search%' OR u.email LIKE '%$search%')";
    }
}

// Get total number of orders for pagination
$count_sql = "SELECT COUNT(*) as total FROM orders o 
             JOIN users u ON o.user_id = u.id 
             $status_filter $search_filter";
$count_result = mysqli_query($conn, $count_sql);
$total_orders = mysqli_fetch_assoc($count_result)['total'];
$total_pages = ceil($total_orders / $items_per_page);

// Get orders with pagination
$orders_sql = "SELECT o.*, u.username, u.email FROM orders o 
              JOIN users u ON o.user_id = u.id 
              $status_filter $search_filter
              ORDER BY o.order_date DESC 
              LIMIT $offset, $items_per_page";
$orders_result = mysqli_query($conn, $orders_sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders - BLASTICAKES & CRAFTS Admin</title>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f4f6f9;
        }
        header {
            background-color: #343a40;
            color: white;
            padding: 1rem;
        }
        .container {
            width: 90%;
            margin: 0 auto;
            padding: 20px;
        }
        nav {
            float: right;
        }
        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
        }
        nav li {
            display: inline;
            margin-left: 15px;
        }
        nav a {
            color: white;
            text-decoration: none;
        }
        h2 {
            color: #333;
            margin-top: 20px;
        }
        .btn {
            display: inline-block;
            background-color: #007bff;
            color: white;
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 14px;
        }
        .btn:hover {
            background-color: #0069d9;
        }
        .btn-secondary {
            background-color: #6c757d;
        }
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        .btn-success {
            background-color: #28a745;
        }
        .btn-success:hover {
            background-color: #218838;
        }
        .btn-danger {
            background-color: #dc3545;
        }
        .btn-danger:hover {
            background-color: #c82333;
        }
        .success-message {
            background-color: #d4edda;
            color: #155724;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        .error-message {
            background-color: #f8d7da;
            color: #721c24;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
        }
        .back-link {
            display: inline-block;
            margin-bottom: 20px;
            color: #007bff;
            text-decoration: none;
        }
        .back-link:hover {
            text-decoration: underline;
        }
        .card {
            background-color: white;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        .order-meta {
            display: flex;
            justify-content: space-between;
            flex-wrap: wrap;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        .order-meta-item {
            margin-bottom: 10px;
            flex-basis: 48%;
        }
        .order-meta-label {
            font-weight: bold;
            color: #666;
        }
        .order-status {
            display: inline-block;
            padding: 5px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: bold;
            text-transform: uppercase;
        }
        .status-pending {
            background-color: #ffeeba;
            color: #856404;
        }
        .status-processing {
            background-color: #b8daff;
            color: #004085;
        }
        .status-completed {
            background-color: #c3e6cb;
            color: #155724;
        }
        .status-cancelled {
            background-color: #f5c6cb;
            color: #721c24;
        }
        .order-items {
            margin-top: 20px;
        }
        .order-item {
            display: flex;
            margin-bottom: 15px;
            padding-bottom: 15px;
            border-bottom: 1px solid #eee;
        }
        .order-item-image {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 4px;
            margin-right: 15px;
        }
        .order-item-details {
            flex-grow: 1;
        }
        .order-item-name {
            font-weight: bold;
            font-size: 16px;
            margin-bottom: 5px;
        }
        .order-item-price {
            color: #666;
        }
        .order-item-quantity {
            color: #666;
        }
        .order-item-total {
            font-weight: bold;
            margin-top: 5px;
        }
        .order-total {
            font-size: 18px;
            font-weight: bold;
            text-align: right;
            margin-top: 20px;
            padding-top: 15px;
            border-top: 1px solid #eee;
        }
        .status-form {
            margin-top: 20px;
            padding-top: 20px;
            border-top: 1px solid #eee;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        select, input[type="text"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .orders-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        .orders-table th, .orders-table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        .orders-table th {
            background-color: #f8f9fa;
            color: #495057;
        }
        .orders-table tr:hover {
            background-color: #f8f9fa;
        }
        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }
        .pagination a, .pagination span {
            display: inline-block;
            padding: 8px 16px;
            margin: 0 4px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-decoration: none;
            color: #007bff;
        }
        .pagination a:hover {
            background-color: #f8f9fa;
        }
        .pagination .active {
            background-color: #007bff;
            color: white;
            border-color: #007bff;
        }
        .pagination .disabled {
            color: #6c757d;
            cursor: not-allowed;
        }
        .filter-form {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        .filter-form select, .filter-form input {
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .filter-form button {
            padding: 8px 16px;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>BLASTICAKES & CRAFTS Admin</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="admin.php">Dashboard</a></li>
                    <li><a href="add_product.php">Products</a></li>
                    <li><a href="admin_orders.php">Orders</a></li>
                    <li><a href="admin_users.php">Users</a></li>
                    <li><a href="logout.php">Logout (<?php echo $username; ?>)</a></li>
                </ul>
            </nav>
        </div>
    </header>
    
    <div class="container">
        <?php if (isset($_GET['order_id'])): ?>
            <!-- Order Details View -->
            <a href="admin_orders.php" class="back-link">← Back to Orders List</a>
            
            <h2>Order #<?php echo $order_id; ?> Details</h2>
            
            <?php if (!empty($success_message)): ?>
                <div class="success-message"><?php echo $success_message; ?></div>
            <?php endif; ?>
            
            <?php if (!empty($error_message)): ?>
                <div class="error-message"><?php echo $error_message; ?></div>
            <?php endif; ?>
            
            <?php if (isset($order)): ?>
                <div class="card">
                    <div class="order-meta">
                        <div class="order-meta-item">
                            <div class="order-meta-label">Order Date:</div>
                            <div><?php echo date('F j, Y, g:i a', strtotime($order['order_date'])); ?></div>
                        </div>
                        
                        <div class="order-meta-item">
                            <div class="order-meta-label">Status:</div>
                            <div>
                                <span class="order-status status-<?php echo strtolower($order['status']); ?>">
                                    <?php echo $order['status']; ?>
                                </span>
                            </div>
                        </div>
                        
                        <div class="order-meta-item">
                            <div class="order-meta-label">Customer:</div>
                            <div><?php echo htmlspecialchars($order['username']); ?> (<?php echo htmlspecialchars($order['email']); ?>)</div>
                        </div>
                        
                        <div class="order-meta-item">
                            <div class="order-meta-label">Total Amount:</div>
                            <div>₱<?php echo number_format($order['total_amount'], 2); ?></div>
                        </div>
                        
                        <div class="order-meta-item">
                            <div class="order-meta-label">Fulfillment Method:</div>
                            <div><?php echo ucfirst(htmlspecialchars($order['fulfillment_option'])); ?></div>
                        </div>

                                                <div class="order-meta-item">
                            <div class="order-meta-label">Payment Method:</div>
                            <div><?php echo htmlspecialchars($order['payment_method']); ?></div>
                        </div>
                        
                        <div class="order-meta-item">
                            <div class="order-meta-label">Phone:</div>
                            <div><?php echo htmlspecialchars($order['phone']); ?></div>
                        </div>
                        
                        <?php if ($order['fulfillment_option'] == 'delivery'): ?>
                            <div class="order-meta-item">
                                <div class="order-meta-label">Delivery Address:</div>
                                <div><?php echo nl2br(htmlspecialchars($order['address'])); ?></div>
                            </div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="order-items">
                        <h3>Order Items</h3>
                        
                        <?php foreach ($order_items as $item): ?>
                            <div class="order-item">
                                <img src="images/<?php echo $item['image']; ?>" alt="<?php echo $item['name']; ?>" class="order-item-image">
                                <div class="order-item-details">
                                    <div class="order-item-name"><?php echo htmlspecialchars($item['name']); ?></div>
                                    <div class="order-item-price">₱<?php echo number_format($item['price'], 2); ?></div>
                                    <div class="order-item-quantity">Quantity: <?php echo $item['quantity']; ?></div>
                                    <div class="order-item-total">Subtotal: ₱<?php echo number_format($item['price'] * $item['quantity'], 2); ?></div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                        
                        <div class="order-total">
                            Total: ₱<?php echo number_format($order['total_amount'], 2); ?>
                        </div>
                    </div>
                    
                    <div class="status-form">
                        <h3>Update Order Status</h3>
                        <form method="post" action="admin_orders.php?order_id=<?php echo $order_id; ?>">
                            <div class="form-group">
                                <label for="status">New Status:</label>
                                <select id="status" name="status" required>
                                    <option value="Pending" <?php echo $order['status'] == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                                    <option value="Processing" <?php echo $order['status'] == 'Processing' ? 'selected' : ''; ?>>Processing</option>
                                    <option value="Completed" <?php echo $order['status'] == 'Completed' ? 'selected' : ''; ?>>Completed</option>
                                    <option value="Cancelled" <?php echo $order['status'] == 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                </select>
                            </div>
                            <button type="submit" name="update_status" class="btn btn-primary">Update Status</button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>
        <?php else: ?>
            <!-- Orders List View -->
            <h2>Manage Orders</h2>
            
            <?php if (!empty($success_message)): ?>
                <div class="success-message"><?php echo $success_message; ?></div>
            <?php endif; ?>
            
            <?php if (!empty($error_message)): ?>
                <div class="error-message"><?php echo $error_message; ?></div>
            <?php endif; ?>
            
            <div class="card">
                <form method="get" action="admin_orders.php" class="filter-form">
                    <select name="status">
                        <option value="">All Statuses</option>
                        <option value="Pending" <?php echo isset($_GET['status']) && $_GET['status'] == 'Pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="Processing" <?php echo isset($_GET['status']) && $_GET['status'] == 'Processing' ? 'selected' : ''; ?>>Processing</option>
                        <option value="Completed" <?php echo isset($_GET['status']) && $_GET['status'] == 'Completed' ? 'selected' : ''; ?>>Completed</option>
                        <option value="Cancelled" <?php echo isset($_GET['status']) && $_GET['status'] == 'Cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                    </select>
                    <input type="text" name="search" placeholder="Search by order ID or customer" value="<?php echo isset($_GET['search']) ? htmlspecialchars($_GET['search']) : ''; ?>">
                    <button type="submit" class="btn">Filter</button>
                    <a href="admin_orders.php" class="btn btn-secondary">Reset</a>
                </form>
                
                <?php if ($orders_result && mysqli_num_rows($orders_result) > 0): ?>
                    <table class="orders-table">
                        <thead>
                            <tr>
                                <th>Order ID</th>
                                <th>Customer</th>
                                <th>Date</th>
                                <th>Total</th>
                                <th>Status</th>
                                <th>Fulfillment</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($order = mysqli_fetch_assoc($orders_result)): ?>
                                <tr>
                                    <td>#<?php echo $order['id']; ?></td>
                                    <td><?php echo htmlspecialchars($order['username']); ?></td>
                                    <td><?php echo date('M j, Y, g:i a', strtotime($order['order_date'])); ?></td>
                                    <td>₱<?php echo number_format($order['total_amount'], 2); ?></td>
                                    <td>
                                        <span class="order-status status-<?php echo strtolower($order['status']); ?>">
                                            <?php echo $order['status']; ?>
                                        </span>
                                    </td>
                                    <td><?php echo ucfirst($order['fulfillment_option']); ?></td>
                                    <td>
                                        <a href="admin_orders.php?order_id=<?php echo $order['id']; ?>" class="btn btn-primary">View Details</a>
                                    </td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                    
                    <!-- Pagination -->
                    <?php if ($total_pages > 1): ?>
                        <div class="pagination">
                            <?php if ($page > 1): ?>
                                <a href="admin_orders.php?page=<?php echo $page - 1; ?><?php echo isset($_GET['status']) ? '&status=' . $_GET['status'] : ''; ?><?php echo isset($_GET['search']) ? '&search=' . urlencode($_GET['search']) : ''; ?>">Previous</a>
                            <?php else: ?>
                                <span class="disabled">Previous</span>
                            <?php endif; ?>
                            
                            <?php for ($i = 1; $i <= $total_pages; $i++): ?>
                                <?php if ($i == $page): ?>
                                    <span class="active"><?php echo $i; ?></span>
                                <?php else: ?>
                                    <a href="admin_orders.php?page=<?php echo $i; ?><?php echo isset($_GET['status']) ? '&status=' . $_GET['status'] : ''; ?><?php echo isset($_GET['search']) ? '&search=' . urlencode($_GET['search']) : ''; ?>"><?php echo $i; ?></a>
                                <?php endif; ?>
                            <?php endfor; ?>
                            
                            <?php if ($page < $total_pages): ?>
                                <a href="admin_orders.php?page=<?php echo $page + 1; ?><?php echo isset($_GET['status']) ? '&status=' . $_GET['status'] : ''; ?><?php echo isset($_GET['search']) ? '&search=' . urlencode($_GET['search']) : ''; ?>">Next</a>
                            <?php else: ?>
                                <span class="disabled">Next</span>
                            <?php endif; ?>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <p>No orders found.</p>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
