<?php
// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Get user info
$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];

// Include database connection
require_once 'includes/db.php';

// Check if order ID is provided
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header("Location: my_orders.php");
    exit;
}
$order_id = $_GET['id'];

// Verify the order belongs to the user
$check_query = "SELECT * FROM orders WHERE id = ? AND user_id = ?";
$stmt = mysqli_prepare($conn, $check_query);
mysqli_stmt_bind_param($stmt, "ii", $order_id, $user_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
if (mysqli_num_rows($result) == 0) {
    // Order doesn't exist or doesn't belong to this user
    header("Location: my_orders.php");
    exit;
}
$order = mysqli_fetch_assoc($result);

// Check if order is in editable state (Pending or Processing)
if ($order['status'] != 'Pending' && $order['status'] != 'Processing') {
    $_SESSION['error'] = "This order cannot be edited anymore.";
    header("Location: my_orders.php");
    exit;
}

// Get order items
$items_query = "SELECT oi.*, p.name, p.image FROM order_items oi 
                JOIN products p ON oi.product_id = p.id 
                WHERE oi.order_id = ?";
$stmt = mysqli_prepare($conn, $items_query);
mysqli_stmt_bind_param($stmt, "i", $order_id);
mysqli_stmt_execute($stmt);
$items_result = mysqli_stmt_get_result($stmt);
$order_items = [];
while ($item = mysqli_fetch_assoc($items_result)) {
    $order_items[] = $item;
}

// Get all available products for potential order changes
$products_query = "SELECT * FROM products";
$products_result = mysqli_query($conn, $products_query);
$available_products = [];
while ($product = mysqli_fetch_assoc($products_result)) {
    $available_products[] = $product;
}

// Process form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate and sanitize input
    $fulfillment_option = mysqli_real_escape_string($conn, $_POST['fulfillment_option']);
    $payment_method = mysqli_real_escape_string($conn, $_POST['payment_method']);
    $phone = mysqli_real_escape_string($conn, $_POST['phone']);
    $shipping_address = mysqli_real_escape_string($conn, $_POST['shipping_address']);
    
    // Update order details
    $update_query = "UPDATE orders SET 
                    fulfillment_option = ?, 
                    payment_method = ?, 
                    phone = ?, 
                    shipping_address = ? 
                    WHERE id = ? AND user_id = ?";
    
    $stmt = mysqli_prepare($conn, $update_query);
    mysqli_stmt_bind_param($stmt, "ssssii", $fulfillment_option, $payment_method, $phone, $shipping_address, $order_id, $user_id);
    $update_result = mysqli_stmt_execute($stmt);
    
    // Handle order items changes if any
    if (isset($_POST['item_id']) && is_array($_POST['item_id'])) {
        foreach ($_POST['item_id'] as $key => $item_id) {
            $quantity = (int)$_POST['quantity'][$key];
            
            if ($quantity <= 0) {
                // Remove item if quantity is 0 or negative
                $delete_item_query = "DELETE FROM order_items WHERE id = ? AND order_id = ?";
                $stmt = mysqli_prepare($conn, $delete_item_query);
                mysqli_stmt_bind_param($stmt, "ii", $item_id, $order_id);
                mysqli_stmt_execute($stmt);
            } else {
                // Update item quantity
                $update_item_query = "UPDATE order_items SET quantity = ? WHERE id = ? AND order_id = ?";
                $stmt = mysqli_prepare($conn, $update_item_query);
                mysqli_stmt_bind_param($stmt, "iii", $quantity, $item_id, $order_id);
                mysqli_stmt_execute($stmt);
            }
        }
    }
    
    // Add new items if any
    if (isset($_POST['new_product_id']) && is_array($_POST['new_product_id'])) {
        foreach ($_POST['new_product_id'] as $key => $product_id) {
            if (empty($product_id)) continue;
            
            $quantity = (int)$_POST['new_quantity'][$key];
            if ($quantity <= 0) continue;
            
            // Get product price
            $price_query = "SELECT price FROM products WHERE id = ?";
            $stmt = mysqli_prepare($conn, $price_query);
            mysqli_stmt_bind_param($stmt, "i", $product_id);
            mysqli_stmt_execute($stmt);
            $price_result = mysqli_stmt_get_result($stmt);
            $product = mysqli_fetch_assoc($price_result);
            
            if ($product) {
                $price = $product['price'];
                
                // Insert new item
                $insert_item_query = "INSERT INTO order_items (order_id, product_id, quantity, price) VALUES (?, ?, ?, ?)";
                $stmt = mysqli_prepare($conn, $insert_item_query);
                mysqli_stmt_bind_param($stmt, "iiid", $order_id, $product_id, $quantity, $price);
                mysqli_stmt_execute($stmt);
            }
        }
    }
    
    // Recalculate total amount
    $total_query = "SELECT SUM(quantity * price) as total FROM order_items WHERE order_id = ?";
    $stmt = mysqli_prepare($conn, $total_query);
    mysqli_stmt_bind_param($stmt, "i", $order_id);
    mysqli_stmt_execute($stmt);
    $total_result = mysqli_stmt_get_result($stmt);
    $total_row = mysqli_fetch_assoc($total_result);
    $new_total = $total_row['total'];
    
    // Update order total
    $update_total_query = "UPDATE orders SET total_amount = ? WHERE id = ?";
    $stmt = mysqli_prepare($conn, $update_total_query);
    mysqli_stmt_bind_param($stmt, "di", $new_total, $order_id);
    mysqli_stmt_execute($stmt);
    
    // Add notification
    $notification_title = "Order Updated";
    $notification_message = "Your order #$order_id has been updated successfully.";
    $notification_query = "INSERT INTO notifications (user_id, title, message) VALUES (?, ?, ?)";
    $stmt = mysqli_prepare($conn, $notification_query);
    mysqli_stmt_bind_param($stmt, "iss", $user_id, $notification_title, $notification_message);
    mysqli_stmt_execute($stmt);
    
    $_SESSION['success'] = "Order has been updated successfully.";
    header("Location: my_orders.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Order - BLASTICAKES & CRAFTS</title>
    <!-- Font Awesome for icons -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        
        .container {
            width: 80%;
            margin: 0 auto;
            padding: 20px;
        }
        
        header {
            background-color: #ff6b6b;
            color: white;
            padding: 10px 0;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
        }
        
        header .container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 20px;
        }
        
        header h1 {
            margin: 0;
            font-size: 28px;
        }
        
        nav ul {
            list-style: none;
            display: flex;
            margin: 0;
            padding: 0;
        }
        
        nav ul li {
            margin-left: 20px;
        }
        
        nav ul li a {
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 4px;
            transition: background-color 0.3s;
        }
        
        nav ul li a:hover {
            background-color: rgba(255,255,255,0.2);
        }
        
        footer {
            background-color: #333;
            color: white;
            text-align: center;
            padding: 20px 0;
            margin-top: 50px;
        }
        
        /* User dropdown menu */
        .user-dropdown {
            position: relative;
            display: inline-block;
        }
        
        .user-dropdown-btn {
            display: flex;
            align-items: center;
            color: white;
            text-decoration: none;
            font-weight: bold;
            padding: 5px 10px;
            border-radius: 4px;
            cursor: pointer;
        }
        
        .user-dropdown-btn:hover {
            background-color: rgba(255,255,255,0.2);
        }
        
        .user-dropdown-btn img {
            width: 25px;
            height: 25px;
            border-radius: 50%;
            margin-right: 8px;
            object-fit: cover;
        }
        
        .user-dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 180px;
            box-shadow: 0 8px 16px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 4px;
            overflow: hidden;
        }
        
        .user-dropdown-content a {
            color: #333;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            transition: background-color 0.3s;
        }
        
        .user-dropdown-content a:hover {
            background-color: #f1f1f1;
        }
        
        .user-dropdown:hover .user-dropdown-content {
            display: block;
        }
        
        /* Page specific styles */
        .page-title {
            color: #ff6b6b;
            margin-bottom: 30px;
            text-align: center;
            font-size: 2em;
        }
        
        h2 {
            color: #333;
            margin-top: 20px;
        }
        
        .btn {
            display: inline-block;
            background-color: #ff6b6b;
            color: white;
            padding: 8px 16px;
            text-decoration: none;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 14px;
            margin-right: 5px;
        }
        
        .btn:hover {
            background-color: #ff5252;
        }
        
        .btn-secondary {
            background-color: #6c757d;
        }
        
        .btn-secondary:hover {
            background-color: #5a6268;
        }
        
        .form-container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            padding: 20px;
            margin-bottom: 30px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
            color: #555;
        }
        
        .form-control {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            box-sizing: border-box;
        }
        
        .form-control:focus {
            border-color: #ff6b6b;
            outline: none;
        }
        
        .order-items {
            margin-top: 30px;
        }
        
        .order-item {
            display: flex;
            align-items: center;
            padding: 15px;
            border-bottom: 1px solid #eee;
        }
        
        .order-item:last-child {
            border-bottom: none;
        }
        
        .item-image {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 4px;
            margin-right: 15px;
        }
        
        .item-details {
            flex-grow: 1;
        }
        
        .item-name {
            font-weight: bold;
            margin-bottom: 5px;
        }
        
        .item-price {
            color: #666;
        }
        
        .item-quantity {
            width: 60px;
            padding: 5px;
            border: 1px solid #ddd;
            border-radius: 4px;
            text-align: center;
        }
        
        .item-total {
            font-weight: bold;
            margin-left: 15px;
            min-width: 80px;
            text-align: right;
        }
        
        .add-item-row {
            display: flex;
            align-items: center;
            padding: 15px;
            background-color: #f9f9f9;
            border-radius: 4px;
            margin-top: 15px;
        }
        
        .add-item-select {
            flex-grow: 1;
            margin-right: 10px;
        }
        
        .remove-item {
            color: #f44336;
            cursor: pointer;
            margin-left: 10px;
        }
        
        .add-item-btn {
            background-color: #4CAF50;
            margin-top: 10px;
        }
        
        .add-item-btn:hover {
            background-color: #45a049;
        }
        
        .order-summary {
            margin-top: 20px;
            text-align: right;
            padding: 15px;
            
            background-color: #f9f9f9;
            border-radius: 4px;
                    }
        
        .order-total {
            font-size: 18px;
            font-weight: bold;
            margin-top: 10px;
        }
        
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
        }
        
        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        
        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        
        .form-actions {
            margin-top: 30px;
            text-align: right;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>BLASTICAKES & CRAFTS</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="products.php">Products</a></li>
                    <li><a href="my_orders.php">My Orders</a></li>
                    <li><a href="cart.php">Cart</a></li>
                    <li class="user-dropdown">
                        <div class="user-dropdown-btn">
                            <?php 
                            // Get user profile picture
                            $profile_pic = !empty($user['profile_picture']) ? $user['profile_picture'] : 'default_profile.png';
                            ?>
                            <img src="profile_images/<?php echo $profile_pic; ?>" alt="Profile">
                            <?php echo $username; ?>
                        </div>
                        <div class="user-dropdown-content">
                            <a href="account.php"><i class="fas fa-user"></i> My Account</a>
                            <a href="my_orders.php"><i class="fas fa-shopping-bag"></i> My Orders</a>
                            <a href="change_password.php"><i class="fas fa-key"></i> Change Password</a>
                            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
                        </div>
                    </li>
                </ul>
            </nav>
        </div>
    </header>
    
    <div class="container">
        <h2 class="page-title">Edit Order #<?php echo $order_id; ?></h2>
        
        <?php if (isset($_SESSION['error'])): ?>
            <div class="alert alert-danger">
                <?php 
                echo $_SESSION['error'];
                unset($_SESSION['error']);
                ?>
            </div>
        <?php endif; ?>
        
        <form method="post" action="">
            <div class="form-container">
                <h3>Order Details</h3>
                
                <div class="form-group">
                    <label for="fulfillment_option">Fulfillment Method</label>
                    <select name="fulfillment_option" id="fulfillment_option" class="form-control" required>
                        <option value="pickup" <?php echo ($order['fulfillment_option'] == 'pickup') ? 'selected' : ''; ?>>Pickup</option>
                        <option value="delivery" <?php echo ($order['fulfillment_option'] == 'delivery') ? 'selected' : ''; ?>>Delivery</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="payment_method">Payment Method</label>
                    <select name="payment_method" id="payment_method" class="form-control" required>
                        <option value="Cash on Delivery" <?php echo ($order['payment_method'] == 'Cash on Delivery') ? 'selected' : ''; ?>>Cash on Delivery</option>
                        <option value="GCash" <?php echo ($order['payment_method'] == 'GCash') ? 'selected' : ''; ?>>GCash</option>
                        <option value="Bank Transfer" <?php echo ($order['payment_method'] == 'Bank Transfer') ? 'selected' : ''; ?>>Bank Transfer</option>
                    </select>
                </div>
                
                <div class="form-group">
                    <label for="phone">Phone Number</label>
                    <input type="text" name="phone" id="phone" class="form-control" value="<?php echo htmlspecialchars($order['phone'] ?? ''); ?>" required>
                </div>
                
                <div class="form-group">
                    <label for="shipping_address">Delivery Address</label>
                    <textarea name="shipping_address" id="shipping_address" class="form-control" rows="3" required><?php echo htmlspecialchars($order['shipping_address']); ?></textarea>
                </div>
            </div>
            
            <div class="form-container order-items">
                <h3>Order Items</h3>
                
                <?php foreach ($order_items as $item): ?>
                <div class="order-item">
                    <img src="images/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['name']); ?>" class="item-image">
                    <div class="item-details">
                        <div class="item-name"><?php echo htmlspecialchars($item['name']); ?></div>
                        <div class="item-price">₱<?php echo number_format($item['price'], 2); ?> each</div>
                    </div>
                    <input type="hidden" name="item_id[]" value="<?php echo $item['id']; ?>">
                    <input type="number" name="quantity[]" class="item-quantity" value="<?php echo $item['quantity']; ?>" min="0" max="99">
                    <div class="item-total">₱<?php echo number_format($item['price'] * $item['quantity'], 2); ?></div>
                    <span class="remove-item" onclick="this.parentNode.querySelector('.item-quantity').value=0;"><i class="fas fa-trash"></i></span>
                </div>
                <?php endforeach; ?>
                
                <div id="new-items-container">
                    <!-- New items will be added here -->
                </div>
                
                <button type="button" class="btn add-item-btn" onclick="addNewItemRow()">
                    <i class="fas fa-plus"></i> Add Item
                </button>
                
                <div class="order-summary">
                    <div class="order-total">Total: ₱<?php echo number_format($order['total_amount'], 2); ?></div>
                    <div class="text-muted">Total will be recalculated after saving changes</div>
                </div>
            </div>
            
            <div class="form-actions">
                <a href="my_orders.php" class="btn btn-secondary">Cancel</a>
                <button type="submit" class="btn">Save Changes</button>
            </div>
        </form>
    </div>
    
    <footer>
        <div class="container">
            <p>&copy; <?php echo date('Y'); ?> BLASTICAKES & CRAFTS. All rights reserved.</p>
        </div>
    </footer>
    
    <script>
        function addNewItemRow() {
            const container = document.getElementById('new-items-container');
            const newRow = document.createElement('div');
            newRow.className = 'add-item-row';
            
            newRow.innerHTML = `
                <select name="new_product_id[]" class="form-control add-item-select" required>
                    <option value="">Select a product</option>
                    <?php foreach ($available_products as $product): ?>
                    <option value="<?php echo $product['id']; ?>"><?php echo htmlspecialchars($product['name']); ?> - ₱<?php echo number_format($product['price'], 2); ?></option>
                    <?php endforeach; ?>
                </select>
                <input type="number" name="new_quantity[]" class="item-quantity" value="1" min="1" max="99">
                <span class="remove-item" onclick="this.parentNode.remove();"><i class="fas fa-times"></i></span>
            `;
            
            container.appendChild(newRow);
        }
        
        // Update item totals when quantity changes
        document.addEventListener('input', function(e) {
            if (e.target.classList.contains('item-quantity')) {
                const item = e.target.closest('.order-item');
                if (item) {
                    const price = parseFloat(item.querySelector('.item-price').textContent.replace('₱', '').replace(',', ''));
                    const quantity = parseInt(e.target.value) || 0;
                    const total = price * quantity;
                    item.querySelector('.item-total').textContent = '₱' + total.toFixed(2);
                }
            }
        });
    </script>
</body>
</html>
