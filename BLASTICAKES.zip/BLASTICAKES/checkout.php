<?php
// Start session
session_start();

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit;
}

// Include database connection
require_once 'includes/db.php';  // This is where the database connection is located

// Get user info
$user_id = $_SESSION['user_id'];
$username = $_SESSION['username'];
$is_admin = isset($_SESSION['is_admin']) && $_SESSION['is_admin'] == 1;

// Initialize variables
$cart_items = [];
$total = 0;
$order_id = null;
$qr_code_url = '';
$payment_methods = ['GCash', 'PayMaya', 'Bank Transfer', 'Cash on Delivery'];
$selected_payment = isset($_POST['payment_method']) ? $_POST['payment_method'] : '';
$selected_fulfillment = isset($_POST['fulfillment_option']) ? $_POST['fulfillment_option'] : '';
$errors = [];
$success = false;

// Check if cart exists and has items
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    header("Location: cart.php");
    exit;
}

$cart_items = $_SESSION['cart'];

// Verify stock availability before proceeding
$stock_error = false;
foreach ($cart_items as $id => $item) {
    // Get current stock from database
    $stock_query = "SELECT stock FROM products WHERE id = ?";
    $stmt = mysqli_prepare($conn, $stock_query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    mysqli_stmt_execute($stmt);
    $stock_result = mysqli_stmt_get_result($stmt);
    $product = mysqli_fetch_assoc($stock_result);
    
    // Check if requested quantity exceeds available stock
    if ($item['quantity'] > $product['stock']) {
        $stock_error = true;
        // Redirect back to cart if stock issues are detected
        header("Location: cart.php");
        exit;
    }
}

// Calculate total
foreach ($cart_items as $item) {
    $total += $item['price'] * $item['quantity'];
}

// Process checkout form
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['place_order'])) {
    // Validate form
    if (empty($_POST['full_name'])) {
        $errors[] = 'Full name is required';
    }
    
    if (empty($_POST['phone'])) {
        $errors[] = 'Phone number is required';
    }
    
    if (empty($_POST['fulfillment_option'])) {
        $errors[] = 'Please select a fulfillment option (Walk-in pickup or Delivery)';
    }
    
    // If delivery is selected, validate address fields
    if ($_POST['fulfillment_option'] === 'delivery') {
        if (empty($_POST['email'])) {
            $errors[] = 'Email is required for delivery';
        } elseif (!filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)) {
            $errors[] = 'Invalid email format';
        }
            
        if (empty($_POST['address'])) {
            $errors[] = 'Address is required for delivery';
        }
    }
    
    if (empty($_POST['payment_method'])) {
        $errors[] = 'Payment method is required';
    }
    
    // If no errors, process the order
    if (empty($errors)) {
        // Start transaction
        mysqli_begin_transaction($conn);
            
        try {
            // Create order
            $full_name = mysqli_real_escape_string($conn, $_POST['full_name']);
            $phone = mysqli_real_escape_string($conn, $_POST['phone']);
            $fulfillment_option = mysqli_real_escape_string($conn, $_POST['fulfillment_option']);
            $payment_method = mysqli_real_escape_string($conn, $_POST['payment_method']);
            
            // Set optional fields based on fulfillment option
            $email = ($fulfillment_option === 'delivery' && isset($_POST['email'])) ? 
                mysqli_real_escape_string($conn, $_POST['email']) : '';
            $address = ($fulfillment_option === 'delivery' && isset($_POST['address'])) ? 
                mysqli_real_escape_string($conn, $_POST['address']) : '';
            
            // Check if orders table exists
            $table_exists = mysqli_query($conn, "SHOW TABLES LIKE 'orders'");
            
            if (mysqli_num_rows($table_exists) == 0) {
                // Create orders table if it doesn't exist
                $create_orders_table = "CREATE TABLE orders (
                    id INT(11) AUTO_INCREMENT PRIMARY KEY,
                    user_id INT(11) NOT NULL,
                    full_name VARCHAR(100) NOT NULL,
                    email VARCHAR(100) NOT NULL,
                    address TEXT NOT NULL,
                    phone VARCHAR(20) NOT NULL,
                    payment_method VARCHAR(50) NOT NULL,
                    fulfillment_option VARCHAR(20) NOT NULL,
                    total_amount DECIMAL(10,2) NOT NULL,
                    status ENUM('pending', 'processing', 'completed', 'cancelled') DEFAULT 'pending',
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (user_id) REFERENCES users(id)
                )";
                mysqli_query($conn, $create_orders_table);
            } else {
                // Check if the required columns exist in the orders table
                $columns_result = mysqli_query($conn, "SHOW COLUMNS FROM orders");
                $columns = [];
                while ($column = mysqli_fetch_assoc($columns_result)) {
                    $columns[] = $column['Field'];
                }
                
                // Add missing columns if needed
                $required_columns = ['full_name', 'email', 'address', 'phone', 'payment_method', 'fulfillment_option'];
                foreach ($required_columns as $column) {
                    if (!in_array($column, $columns)) {
                        $column_type = ($column == 'address') ? 'TEXT' :
                                       (($column == 'fulfillment_option') ? 'VARCHAR(20)' : 'VARCHAR(100)');
                        mysqli_query($conn, "ALTER TABLE orders ADD COLUMN $column $column_type NOT NULL");
                    }
                }
            }
            
            // Check if order_items table exists
            $table_exists = mysqli_query($conn, "SHOW TABLES LIKE 'order_items'");
            
            if (mysqli_num_rows($table_exists) == 0) {
                // Create order_items table if it doesn't exist
                $create_order_items_table = "CREATE TABLE order_items (
                    id INT(11) AUTO_INCREMENT PRIMARY KEY,
                    order_id INT(11) NOT NULL,
                    product_id INT(11) NOT NULL,
                    quantity INT(11) NOT NULL,
                    price DECIMAL(10,2) NOT NULL,
                    FOREIGN KEY (order_id) REFERENCES orders(id),
                    FOREIGN KEY (product_id) REFERENCES products(id)
                )";
                mysqli_query($conn, $create_order_items_table);
            }
            
            // Verify stock one more time before placing order
            foreach ($cart_items as $id => $item) {
                $stock_query = "SELECT stock FROM products WHERE id = ?";
                $stmt = mysqli_prepare($conn, $stock_query);
                mysqli_stmt_bind_param($stmt, "i", $id);
                mysqli_stmt_execute($stmt);
                $stock_result = mysqli_stmt_get_result($stmt);
                $product = mysqli_fetch_assoc($stock_result);
                
                if ($item['quantity'] > $product['stock']) {
                    throw new Exception("Product '{$item['name']}' is out of stock. Available: {$product['stock']}");
                }
            }
            
            // Insert order
            $sql = "INSERT INTO orders (user_id, full_name, email, address, phone, payment_method, fulfillment_option, total_amount, status)
                    VALUES ($user_id, '$full_name', '$email', '$address', '$phone', '$payment_method', '$fulfillment_option', $total, 'pending')";
            
            if (!mysqli_query($conn, $sql)) {
                throw new Exception(mysqli_error($conn));
            }
            
            // Get order ID
            $order_id = mysqli_insert_id($conn);
            
            // Insert order items
            foreach ($cart_items as $item) {
                $product_id = $item['id'];
                $quantity = $item['quantity'];
                $price = $item['price'];
                
                $sql = "INSERT INTO order_items (order_id, product_id, quantity, price)
                        VALUES ($order_id, $product_id, $quantity, $price)";
                
                if (!mysqli_query($conn, $sql)) {
                    throw new Exception(mysqli_error($conn));
                }
                
                // Update product stock
                $sql = "UPDATE products SET stock = stock - $quantity WHERE id = $product_id";
                
                if (!mysqli_query($conn, $sql)) {
                    throw new Exception(mysqli_error($conn));
                }
            }
            
            // Generate QR code data
            $qr_data = json_encode([
                'order_id' => $order_id,
                'user_id' => $user_id,
                'total' => $total,
                'payment_method' => $payment_method,
                'fulfillment_option' => $fulfillment_option,
                'timestamp' => time()
            ]);
            
            // Generate QR code URL using a free API
            $qr_code_url = 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=' . urlencode($qr_data);
            
            // Commit transaction
            mysqli_commit($conn);
            
            // Clear cart
            $_SESSION['cart'] = [];
            
            // Set success flag
            $success = true;
            
        } catch (Exception $e) {
            // Rollback transaction on error
            mysqli_rollback($conn);
            $errors[] = 'An error occurred: ' . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout - BLASTICAKES & CRAFTS</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            margin: 0;
            padding: 0;
            background-color: #f9f9f9;
        }
        header {
            background-color: #ff6b6b;
            color: white;
            padding: 1rem;
        }
        .container {
            width: 80%;
            margin: 0 auto;
            overflow: hidden;
        }
        nav {
            float: right;
        }
        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
        }
        nav li {
            display: inline;
            margin-left: 15px;
        }
        nav a {
            color: white;
            text-decoration: none;
        }
        .checkout-container {
            display: flex;
            gap: 20px;
            margin-top: 20px;
        }
        .checkout-form {
            flex: 2;
            background: white;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
        }
        .order-summary {
            flex: 1;
            background: white;
            border-radius: 5px;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0,0,0,0.1);
            align-self: flex-start;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }
        input[type="text"],
        input[type="email"],
        input[type="tel"],
        textarea,
        select {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .btn {
            display: inline-block;
            background-color: #ff6b6b;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 4px;
            border: none;
            cursor: pointer;
            font-size: 16px;
        }
        .btn:hover {
            background-color: #ff5252;
        }
        .cart-item {
            display: flex;
            margin-bottom: 10px;
            padding-bottom: 10px;
            border-bottom: 1px solid #eee;
        }
        .cart-item-image {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 4px;
            margin-right: 10px;
        }
        .cart-item-details {
            flex-grow: 1;
        }
        .cart-item-name {
            font-weight: bold;
        }
        .cart-item-price {
            color: #666;
        }
        .cart-item-quantity {
            color: #666;
        }
        .cart-total {
            font-size: 1.2em;
            font-weight: bold;
            margin-top: 15px;
            text-align: right;
        }
        .errors {
            color: #721c24;
            background-color: #f8d7da;
            padding: 10px;
            border-radius: 4px;
            margin-bottom: 15px;
            list-style-position: inside;
        }
        .success-message {
            text-align: center;
            padding: 20px;
        }
        .qr-code {
            text-align: center;
            margin: 20px 0;
        }
        .qr-code img {
            max-width: 200px;
            margin: 0 auto;
        }
        .order-details {
            background: #f9f9f9;
            padding: 15px;
            border-radius: 4px;
            margin-top: 20px;
        }
        .order-details h3 {
            margin-top: 0;
        }
        .payment-instructions {
            margin-top: 20px;
            padding: 15px;
            background: #fff3cd;
            border-radius: 4px;
            border-left: 4px solid #ffc107;
        }
        .fulfillment-options {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
        }
        .fulfillment-option {
            flex: 1;
            border: 1px solid #ddd;
            border-radius: 4px;
            padding: 15px;
            cursor: pointer;
            transition: all 0.3s;
            text-align: center;
        }
        .fulfillment-option:hover {
                        border-color: #ff6b6b;
        }
        .fulfillment-option.selected {
            border-color: #ff6b6b;
            background-color: #fff0f0;
        }
        .fulfillment-option i {
            font-size: 24px;
            margin-bottom: 10px;
            color: #ff6b6b;
        }
        .delivery-fields {
            display: none;
        }
        .delivery-fields.active {
            display: block;
        }
    </style>
</head>
<body>
    <header>
        <div class="container">
            <h1>BLASTICAKES & CRAFTS</h1>
            <nav>
                <ul>
                    <li><a href="index.php">Home</a></li>
                    <li><a href="products.php">Products</a></li>
                    <li><a href="cart.php">Cart</a></li>
                    <?php if ($is_admin): ?>
                        <li><a href="admin.php">Admin Panel</a></li>
                    <?php endif; ?>
                    <li><a href="logout.php">Logout (<?php echo $username; ?>)</a></li>
                </ul>
            </nav>
        </div>
    </header>
    
    <div class="container">
        <h2>Checkout</h2>
        
        <?php if (!empty($errors)): ?>
            <ul class="errors">
                
                <?php foreach ($errors as $error): ?>
                    <li><?php echo $error; ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="success-message">
                <h3>Thank you for your order!</h3>
                <p>Your order has been placed successfully. Order ID: #<?php echo $order_id; ?></p>
                
                <div class="qr-code">
                    <h4>Scan this QR code for your order details</h4>
                    <img src="<?php echo $qr_code_url; ?>" alt="Order QR Code">
                </div>
                
                <div class="order-details">
                    <h3>Order Summary</h3>
                    <p><strong>Fulfillment Method:</strong> <?php echo ucfirst($selected_fulfillment); ?></p>
                    <?php foreach ($cart_items as $item): ?>
                        <div class="cart-item">
                            <div class="cart-item-details">
                                <div class="cart-item-name"><?php echo $item['name']; ?></div>
                                <div class="cart-item-price">₱<?php echo number_format($item['price'], 2); ?> x <?php echo $item['quantity']; ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    <div class="cart-total">Total: ₱<?php echo number_format($total, 2); ?></div>
                </div>
                
                <?php if ($selected_payment != 'Cash on Delivery'): ?>
                    <div class="payment-instructions">
                        <h4>Payment Instructions</h4>
                        <p>Please complete your payment using the selected method: <strong><?php echo $selected_payment; ?></strong></p>
                        <?php if ($selected_payment == 'GCash'): ?>
                            <p>GCash Number: 09123456789</p>
                            <p>Account Name: BLASTICAKES & CRAFTS</p>
                        <?php elseif ($selected_payment == 'PayMaya'): ?>
                            <p>PayMaya Number: 09123456789</p>
                            <p>Account Name: BLASTICAKES & CRAFTS</p>
                        <?php elseif ($selected_payment == 'Bank Transfer'): ?>
                            <p>Bank: BDO</p>
                            <p>Account Number: 1234567890</p>
                            <p>Account Name: BLASTICAKES & CRAFTS</p>
                        <?php endif; ?>
                        <p>Please include your Order ID (#<?php echo $order_id; ?>) in the payment reference.</p>
                    </div>
                <?php endif; ?>
                
                <?php if ($selected_fulfillment == 'pickup'): ?>
                    <div class="payment-instructions">
                        <h4>Pickup Instructions</h4>
                        <p>You can pick up your order at our store:</p>
                        <p><strong>Address:</strong> 123 Cake Street, Barangay Sweet Tooth, Laguna</p>
                        <p><strong>Store Hours:</strong> Monday to Saturday, 9:00 AM to 6:00 PM</p>
                        <p>Please bring a copy of your order confirmation or QR code when picking up your order.</p>
                    </div>
                <?php endif; ?>
                
                <p><a href="products.php" class="btn">Continue Shopping</a></p>
            </div>
        <?php else: ?>
            <div class="checkout-container">
                <div class="checkout-form">
                    <h3>Order Information</h3>
                    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" id="checkout-form">
                        <h4>Select Fulfillment Option</h4>
                        <div class="fulfillment-options">
                            <div class="fulfillment-option <?php echo $selected_fulfillment == 'pickup' ? 'selected' : ''; ?>" id="pickup-option">
                                <i class="fas fa-store"></i>
                                <h4>✅ Walk-in pickup</h4>
                                <p>Pick up your order at our store</p>
                                <input type="radio" name="fulfillment_option" value="pickup" id="pickup" <?php echo $selected_fulfillment == 'pickup' ? 'checked' : ''; ?> style="display:none;">
                            </div>
                            <div class="fulfillment-option <?php echo $selected_fulfillment == 'delivery' ? 'selected' : ''; ?>" id="delivery-option">
                                <i class="fas fa-truck"></i>
                                <h4>🚚 Delivery</h4>
                                <p>We'll deliver to your address</p>
                                <input type="radio" name="fulfillment_option" value="delivery" id="delivery" <?php echo $selected_fulfillment == 'delivery' ? 'checked' : ''; ?> style="display:none;">
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="full_name">Full Name</label>
                            <input type="text" id="full_name" name="full_name" value="<?php echo isset($_POST['full_name']) ? htmlspecialchars($_POST['full_name']) : ''; ?>" required>
                        </div>
                        
                        <div class="form-group">
                            <label for="phone">Phone Number</label>
                            <input type="tel" id="phone" name="phone" value="<?php echo isset($_POST['phone']) ? htmlspecialchars($_POST['phone']) : ''; ?>" required>
                        </div>
                        
                        <div id="delivery-fields" class="delivery-fields <?php echo $selected_fulfillment == 'delivery' ? 'active' : ''; ?>">
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="email" id="email" name="email" value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>">
                            </div>
                            
                            <div class="form-group">
                                <label for="address">Delivery Address</label>
                                <textarea id="address" name="address" rows="3"><?php echo isset($_POST['address']) ? htmlspecialchars($_POST['address']) : ''; ?></textarea>
                            </div>
                        </div>
                        
                        <div class="form-group">
                            <label for="payment_method">Payment Method</label>
                            <select id="payment_method" name="payment_method" required>
                                <option value="">Select Payment Method</option>
                                <?php foreach ($payment_methods as $method): ?>
                                    <option value="<?php echo $method; ?>" <?php echo $selected_payment == $method ? 'selected' : ''; ?>><?php echo $method; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        
                        <button type="submit" name="place_order" class="btn">Place Order</button>
                    </form>
                </div>
                
                <div class="order-summary">
                    <h3>Order Summary</h3>
                    <?php foreach ($cart_items as $item): ?>
                        <div class="cart-item">
                            <img src="images/<?php echo $item['image']; ?>" alt="<?php echo $item['name']; ?>" class="cart-item-image">
                            <div class="cart-item-details">
                                <div class="cart-item-name"><?php echo $item['name']; ?></div>
                                <div class="cart-item-price">₱<?php echo number_format($item['price'], 2); ?></div>
                                <div class="cart-item-quantity">Quantity: <?php echo $item['quantity']; ?></div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                    <div class="cart-total">Total: ₱<?php echo number_format($total, 2); ?></div>
                </div>
            </div>
        <?php endif; ?>
    </div>
    <script>
        // JavaScript to handle the fulfillment option selection
        document.addEventListener('DOMContentLoaded', function() {
            const pickupOption = document.getElementById('pickup-option');
            const deliveryOption = document.getElementById('delivery-option');
            const pickupRadio = document.getElementById('pickup');
            const deliveryRadio = document.getElementById('delivery');
            const deliveryFields = document.getElementById('delivery-fields');
            
            pickupOption.addEventListener('click', function() {
                pickupOption.classList.add('selected');
                deliveryOption.classList.remove('selected');
                pickupRadio.checked = true;
                deliveryFields.classList.remove('active');
                
                // Make delivery fields not required
                document.getElementById('email').required = false;
                document.getElementById('address').required = false;
            });
            
            deliveryOption.addEventListener('click', function() {
                deliveryOption.classList.add('selected');
                pickupOption.classList.remove('selected');
                deliveryRadio.checked = true;
                deliveryFields.classList.add('active');
                
                // Make delivery fields required
                document.getElementById('email').required = true;
                document.getElementById('address').required = true;
            });
            
            // Set initial state based on selected option
            if (pickupRadio.checked) {
                pickupOption.click();
            } else if (deliveryRadio.checked) {
                deliveryOption.click();
            } else {
                // Default to pickup if nothing is selected
                pickupOption.click();
            }
        });
    </script>
</body>
</html>
